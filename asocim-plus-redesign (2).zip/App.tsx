
import React, { useState, useEffect } from 'react';
import { Login } from './views/Login';
import { Dashboard } from './views/Dashboard';
import { CourseView } from './views/CourseView';
import { 
    GradesView, CalendarView, CommunityView, MessagesView, 
    ProfileView, EditProfileView, HelpCenterView,
    BlogView, BadgesView, ContentBankView
} from './views/SecondaryViews';
import { Landing } from './views/Landing';
import { Header } from './components/Header';
import { AccessibilityWidget } from './components/AccessibilityWidget';
import { Toast, ToastType } from './components/ui/Toast';
import { Page, Language } from './types';

interface ToastState {
  show: boolean;
  message: string;
  type: ToastType;
}

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>(Page.LANDING);
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>(null);
  const [toast, setToast] = useState<ToastState>({ show: false, message: '', type: 'info' });
  const [landingTab, setLandingTab] = useState('Inicio');
  const [language, setLanguage] = useState<Language>('EN');
  const [userName, setUserName] = useState('Virtualizadora AC');

  const showToast = (message: string, type: ToastType = 'info') => {
    setToast({ show: true, message, type });
  };

  useEffect(() => {
      const handleNavigation = (e: Event) => {
          const detail = (e as CustomEvent).detail;
          if (detail === 'EDIT_PROFILE') setCurrentPage(Page.EDIT_PROFILE);
      };
      window.addEventListener('navigate', handleNavigation);
      return () => window.removeEventListener('navigate', handleNavigation);
  }, []);

  const handleLogin = (name?: string) => {
    if (name) setUserName(name);
    showToast(`Welcome back, ${name || userName}!`, 'success');
    setTimeout(() => setCurrentPage(Page.DASHBOARD), 500);
  };

  const handleNavigate = (page: Page) => {
    if (currentPage === page) return;
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setCurrentPage(page);
    if (page === Page.DASHBOARD) {
        setSelectedCourseId(null);
    }
  };

  const handleLandingNavigate = (tab: string) => {
    setLandingTab(tab);
    setCurrentPage(Page.LANDING);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCourseSelect = (courseId: string) => {
    setSelectedCourseId(courseId);
    setCurrentPage(Page.COURSE);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col text-slate-800 bg-slate-50 font-sans">
      {toast.show && (
        <Toast 
          message={toast.message} 
          type={toast.type} 
          onClose={() => setToast({ ...toast, show: false })} 
        />
      )}

      {currentPage !== Page.LOGIN && currentPage !== Page.LANDING && (
        <Header 
            onNavigate={handleNavigate} 
            activePage={currentPage} 
            userName={userName}
            onShowToast={showToast}
            onLandingNavigate={handleLandingNavigate}
            language={language}
            setLanguage={setLanguage}
        />
      )}
      
      <main className="flex-grow relative">
        {currentPage === Page.LANDING && (
            <Landing 
                onEnterApp={() => handleNavigate(Page.LOGIN)} 
                onShowToast={showToast} 
                initialTab={landingTab}
                language={language}
                setLanguage={setLanguage}
            />
        )}
        {currentPage === Page.LOGIN && (
            <Login 
                onLogin={handleLogin} 
                onShowToast={showToast} 
                onBack={() => handleNavigate(Page.LANDING)} 
                language={language}
            />
        )}
        {currentPage === Page.DASHBOARD && (
            <Dashboard 
                onCourseSelect={handleCourseSelect} 
                onShowToast={showToast}
                onNavigate={handleNavigate}
                language={language}
                userName={userName}
            />
        )}
        {currentPage === Page.COURSE && (
            <CourseView 
                courseId={selectedCourseId} 
                onBack={() => handleNavigate(Page.DASHBOARD)} 
                onShowToast={showToast}
                language={language}
            />
        )}
        {currentPage === Page.GRADES && <GradesView language={language} />}
        {currentPage === Page.CALENDAR && <CalendarView language={language} />}
        {currentPage === Page.COMMUNITY && <CommunityView language={language} />}
        {currentPage === Page.MESSAGES && <MessagesView language={language} />}
        {currentPage === Page.PROFILE && <ProfileView userName={userName} language={language} />}
        {currentPage === Page.EDIT_PROFILE && <EditProfileView userName={userName} onUpdateName={setUserName} language={language} />}
        {currentPage === Page.HELP && <HelpCenterView language={language} />}
        {currentPage === Page.BLOG && <BlogView language={language} />}
        {currentPage === Page.BADGES && <BadgesView language={language} />}
        {currentPage === Page.CONTENT_BANK && <ContentBankView language={language} />}
      </main>

      {currentPage !== Page.LANDING && <AccessibilityWidget />}
    </div>
  );
};

export default App;
