
import { LucideIcon } from 'lucide-react';

export type Language = 'EN' | 'ES' | 'FR';

export enum Page {
  LANDING = 'LANDING',
  LOGIN = 'LOGIN',
  DASHBOARD = 'DASHBOARD',
  COURSE = 'COURSE',
  GRADES = 'GRADES',
  CALENDAR = 'CALENDAR',
  COMMUNITY = 'COMMUNITY',
  MESSAGES = 'MESSAGES',
  PROFILE = 'PROFILE',
  EDIT_PROFILE = 'EDIT_PROFILE',
  HELP = 'HELP',
  BLOG = 'BLOG',
  BADGES = 'BADGES',
  CONTENT_BANK = 'CONTENT_BANK'
}

export interface UserStats {
  label: string;
  value: number;
  color: string;
  total?: number;
}

export interface Course {
  id: string;
  title: string;
  thumbnail: string;
  progress: number;
  category: string;
  isFavorite?: boolean;
}

export interface Question {
  id: string;
  text: string;
  options: string[];
  correct: number;
}

export interface Activity {
  id: string;
  type: 'pdf' | 'link' | 'quiz' | 'video' | 'assignment' | 'h5p-drag';
  title: string;
  isCompleted: boolean;
  isLocked?: boolean;
  fileUrl?: string;
  linkUrl?: string;
  content?: string;
  questions?: Question[];
}

export interface Module {
  id: string;
  title: string;
  description?: string;
  activities: Activity[];
}

export interface BreadcrumbItem {
    label: string;
    href?: string;
}

export interface Participant {
    id: string;
    name: string;
    role: 'Student' | 'Teacher' | 'Admin';
    lastAccess: string;
    avatar: string;
    email: string;
}

export interface GradeItem {
    id: string;
    courseName: string;
    item: string;
    grade: string;
    range: string;
    percentage: string;
    feedback?: string;
}

export interface CalendarEvent {
    id: string;
    title: string;
    date: string;
    time: string;
    type: 'assignment' | 'quiz' | 'meeting' | 'reminder';
    courseId?: string;
}

export interface Message {
    id: string;
    sender: string;
    avatar: string;
    text: string;
    timestamp: string;
    unread: boolean;
}

export interface ForumTopic {
    id: string;
    title: string;
    author: string;
    replies: number;
    views: number;
    lastPost: string;
    category: string;
}
