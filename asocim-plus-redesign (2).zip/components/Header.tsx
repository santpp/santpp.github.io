
import React, { useState, useEffect, useRef } from 'react';
import { 
    Bell, MessageSquare, Search, User, LogOut, HelpCircle, 
    CheckCircle, Clock, AlertCircle, FileText, Menu, X,
    Home, BookOpen, Calendar, Award, Database, PenTool, Globe, ChevronDown
} from 'lucide-react';
import { Page, Language } from '../types';
import { ToastType } from './ui/Toast';
import { TRANSLATIONS } from '../constants';

interface HeaderProps {
  onNavigate: (page: Page) => void;
  activePage: Page;
  userName: string;
  onShowToast: (message: string, type: ToastType) => void;
  onLandingNavigate: (tab: string) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
}

interface Notification {
    id: string;
    text: string;
    time: string;
    unread: boolean;
    type: 'assignment' | 'grade' | 'system';
}

const MOCK_NOTIFICATIONS: Notification[] = [
    { id: '1', text: "Assignment due tomorrow: Final Essay", time: "2 hours ago", unread: true, type: 'assignment' },
    { id: '2', text: "New grade posted: Vocabulary Quiz", time: "Yesterday", unread: true, type: 'grade' },
    { id: '3', text: "System maintenance scheduled for Sunday", time: "2 days ago", unread: false, type: 'system' }
];

export const Header: React.FC<HeaderProps> = ({ onNavigate, activePage, userName, onShowToast, onLandingNavigate, language, setLanguage }) => {
  const [scrolled, setScrolled] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [notifications, setNotifications] = useState(MOCK_NOTIFICATIONS);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Click outside to close dropdowns
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
        if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
            setActiveDropdown(null);
            setMobileMenuOpen(false);
        }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const unreadCount = notifications.filter(n => n.unread).length;

  const markAllRead = () => {
      setNotifications(notifications.map(n => ({ ...n, unread: false })));
      onShowToast("All notifications marked as read", 'success');
  };

  const t = TRANSLATIONS[language].nav;
  const sub = TRANSLATIONS[language].subnav;

  // Mapping for buttons. Key is the translation key.
  const navItems = [
      { key: 'home', label: t.home, target: 'Inicio' },
      { key: 'courses', label: t.courses, target: 'Cursos' },
      { key: 'store', label: t.store, target: 'Tienda' },
      { key: 'classroom', label: t.classroom, target: 'Aula' },
      { key: 'pricing', label: t.pricing, target: 'Precios' },
      { key: 'corporate', label: t.corporate, target: 'Empresa' },
      { key: 'about', label: t.about, target: 'Sobre nosotros' }
  ];

  const subHeaderItems = [
      { label: sub.myCourses, icon: BookOpen, page: Page.DASHBOARD },
      { label: sub.notes, icon: FileText, page: Page.COURSE },
      { label: sub.allCourses, icon: Database, page: Page.DASHBOARD },
      { label: sub.blog, icon: PenTool, page: Page.BLOG },
      { label: sub.calendar, icon: Calendar, page: Page.CALENDAR },
      { label: sub.badges, icon: Award, page: Page.BADGES },
  ];

  const isAppPage = activePage !== Page.LANDING && activePage !== Page.LOGIN;

  return (
    <>
    <header 
        ref={dropdownRef}
        className={`sticky top-0 z-50 transition-all duration-300 bg-white shadow-sm ${scrolled ? 'py-2' : 'py-3'}`}
    >
      <div className="max-w-7xl mx-auto px-4 lg:px-8 flex items-center justify-between">
        <div className="flex items-center gap-8">
          {/* Logo */}
          <div 
            className="flex items-center cursor-pointer select-none group hover:scale-105 transition-transform duration-200" 
            onClick={() => onNavigate(Page.DASHBOARD)}
          >
            <span className="text-2xl font-[900] text-[#002060] tracking-tighter">ASOCIM</span>
            <div className="bg-[#002060] py-0.5 px-1.5 ml-1 rounded-sm flex items-center shadow-sm">
                <span className="text-white text-[10px] font-[800] tracking-widest uppercase">PLUS</span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-6">
            {navItems.map(item => (
                <button 
                    key={item.key}
                    onClick={() => {
                        if (item.key === 'classroom') onNavigate(Page.DASHBOARD);
                        else onLandingNavigate(item.target);
                    }}
                    className={`text-sm font-medium transition-all duration-200 px-1 relative hover:-translate-y-0.5 ${
                        (item.key === 'classroom' && isAppPage) 
                        ? 'text-[#002060] font-bold' 
                        : 'text-slate-600 hover:text-[#002060]'
                    }`}
                >
                    {item.label}
                    {(item.key === 'classroom' && isAppPage) && (
                        <span className="absolute -bottom-1.5 left-0 w-full h-0.5 bg-[#002060] rounded-full"></span>
                    )}
                </button>
            ))}
          </nav>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-3">
            
            {/* Language Switcher */}
            <div className="relative">
                <button 
                    onClick={() => setActiveDropdown(activeDropdown === 'Lang' ? null : 'Lang')}
                    className="flex items-center gap-1 p-2 text-slate-500 hover:bg-slate-100 rounded-full transition-all"
                >
                    <Globe size={18} />
                    <span className="text-xs font-bold">{language}</span>
                    <ChevronDown size={12} />
                </button>
                {activeDropdown === 'Lang' && (
                    <div className="absolute right-0 top-12 bg-white rounded-xl shadow-xl border border-slate-100 py-2 z-50 w-24 animate-scale-in">
                        {(['EN', 'ES', 'FR'] as Language[]).map(lang => (
                            <button 
                                key={lang}
                                onClick={() => { setLanguage(lang); setActiveDropdown(null); }}
                                className={`w-full text-left px-4 py-2 text-sm hover:bg-slate-50 ${language === lang ? 'font-bold text-[#002060]' : 'text-slate-600'}`}
                            >
                                {lang}
                            </button>
                        ))}
                    </div>
                )}
            </div>

            {/* Site Home Button - Only visible inside App */}
            {isAppPage && (
                <button 
                    onClick={() => onLandingNavigate('Inicio')}
                    className="hidden md:flex p-2.5 text-slate-500 hover:bg-blue-50 hover:text-[#002060] rounded-full transition-all hover:scale-105"
                    title="Site Home"
                >
                    <Globe size={20} />
                </button>
            )}

            {/* Expandable Search */}
            <div className={`flex items-center bg-slate-100 rounded-full px-3 transition-all duration-300 ${showSearch ? 'w-48 lg:w-64 ring-2 ring-blue-100 bg-white' : 'w-10 bg-transparent hover:bg-slate-100'}`}>
                <button onClick={() => setShowSearch(!showSearch)} className="py-2 text-slate-500 hover:text-[#002060]">
                    <Search size={20} />
                </button>
                <input 
                    type="text" 
                    placeholder="Search..." 
                    className={`bg-transparent border-none focus:outline-none text-sm ml-2 w-full text-slate-700 placeholder-slate-400 ${showSearch ? 'block' : 'hidden'}`}
                    autoFocus={showSearch}
                />
            </div>

            <div className="flex items-center gap-1 relative">
                {/* Notifications Button */}
                <button 
                    onClick={() => setActiveDropdown(activeDropdown === 'Notifications' ? null : 'Notifications')}
                    className={`p-2.5 text-slate-500 hover:bg-slate-100 hover:text-[#002060] rounded-full relative transition-all hover:scale-105 ${activeDropdown === 'Notifications' ? 'bg-blue-50 text-[#002060]' : ''}`}
                >
                    <Bell size={20} />
                    {unreadCount > 0 && (
                        <span className="absolute top-2.5 right-2.5 w-2 h-2 bg-red-500 rounded-full border border-white animate-pulse"></span>
                    )}
                </button>

                {/* Notifications Dropdown */}
                {activeDropdown === 'Notifications' && (
                    <div className="absolute right-0 top-14 w-80 bg-white rounded-2xl shadow-xl border border-slate-100 py-2 z-50 animate-scale-in origin-top-right">
                        <div className="px-4 py-3 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
                            <h3 className="font-bold text-slate-800">Notifications</h3>
                            {unreadCount > 0 && (
                                <button onClick={markAllRead} className="text-xs font-bold text-blue-600 hover:text-blue-800">
                                    Mark all read
                                </button>
                            )}
                        </div>
                        <div className="max-h-80 overflow-y-auto">
                            {notifications.length === 0 ? (
                                <div className="p-6 text-center text-slate-500 text-sm">No notifications</div>
                            ) : (
                                notifications.map(n => (
                                    <div key={n.id} className={`px-4 py-3 hover:bg-slate-50 cursor-pointer flex gap-3 border-b border-slate-50 last:border-0 ${n.unread ? 'bg-blue-50/30' : ''}`}>
                                        <div className={`mt-1 p-1.5 rounded-full h-fit ${n.type === 'assignment' ? 'bg-red-50 text-red-500' : n.type === 'grade' ? 'bg-emerald-50 text-emerald-500' : 'bg-slate-100 text-slate-500'}`}>
                                            {n.type === 'assignment' && <FileText size={14} />}
                                            {n.type === 'grade' && <CheckCircle size={14} />}
                                            {n.type === 'system' && <AlertCircle size={14} />}
                                        </div>
                                        <div>
                                            <p className={`text-sm ${n.unread ? 'font-bold text-slate-800' : 'text-slate-600'}`}>{n.text}</p>
                                            <p className="text-xs text-slate-400 mt-1 flex items-center gap-1">
                                                <Clock size={10} /> {n.time}
                                            </p>
                                        </div>
                                        {n.unread && <div className="w-2 h-2 rounded-full bg-blue-500 mt-2 flex-shrink-0"></div>}
                                    </div>
                                ))
                            )}
                        </div>
                        <div className="p-2 border-t border-slate-50 text-center">
                            <button className="text-xs font-bold text-[#002060] hover:underline">View All History</button>
                        </div>
                    </div>
                )}
                
                {/* Messages Button */}
                <button 
                    onClick={() => onNavigate(Page.MESSAGES)}
                    className={`p-2.5 text-slate-500 hover:bg-slate-100 hover:text-[#002060] rounded-full transition-all hover:scale-105 ${activePage === Page.MESSAGES ? 'text-[#002060] bg-blue-50' : ''}`}
                >
                    <MessageSquare size={20} />
                </button>
            </div>

            <div className="h-8 w-px bg-slate-200 mx-2 hidden md:block"></div>

            {/* Profile */}
            <div className="relative hidden md:block">
                <button 
                    onClick={() => setActiveDropdown(activeDropdown === 'Profile' ? null : 'Profile')}
                    className="flex items-center gap-3 pl-1 hover:bg-slate-50 rounded-full p-1 pr-3 transition-all group"
                >
                    <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-white shadow-md group-hover:shadow-lg transition-shadow">
                        <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=100&auto=format&fit=crop" alt="Profile" className="w-full h-full object-cover" />
                    </div>
                    <div className="text-left">
                        <p className="text-sm font-bold text-slate-700 group-hover:text-[#002060] transition-colors leading-none">{userName}</p>
                        <p className="text-[10px] text-slate-400 font-medium uppercase tracking-wide mt-1">Student</p>
                    </div>
                </button>

                {/* Profile Dropdown */}
                {activeDropdown === 'Profile' && (
                    <div className="absolute right-0 top-14 w-64 bg-white rounded-2xl shadow-xl border border-slate-100 py-2 z-50 animate-scale-in origin-top-right">
                        <div className="px-5 py-4 border-b border-slate-50 mb-2 bg-slate-50/50">
                            <p className="text-sm font-bold text-slate-800">{userName}</p>
                            <p className="text-xs text-slate-500">student@asocim.org</p>
                        </div>
                        <div className="px-2 space-y-1">
                            <button onClick={() => {setActiveDropdown(null); onNavigate(Page.PROFILE)}} className="w-full text-left px-3 py-2 text-sm text-slate-600 hover:bg-slate-50 rounded-xl flex items-center gap-3 transition-colors">
                                <User size={16} /> Profile & Preferences
                            </button>
                            <button onClick={() => {setActiveDropdown(null); onNavigate(Page.HELP)}} className="w-full text-left px-3 py-2 text-sm text-slate-600 hover:bg-slate-50 rounded-xl flex items-center gap-3 transition-colors">
                                <HelpCircle size={16} /> Help Center
                            </button>
                        </div>
                        <div className="border-t border-slate-100 mt-2 pt-2 px-2">
                            <button onClick={() => {setActiveDropdown(null); onLandingNavigate('Inicio')}} className="w-full text-left px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-xl flex items-center gap-3 transition-colors font-medium">
                                <LogOut size={16} /> Log out
                            </button>
                        </div>
                    </div>
                )}
            </div>

            {/* Mobile Menu Button */}
            <button 
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 text-slate-500"
            >
                {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
          <div className="lg:hidden absolute top-full left-0 w-full bg-white border-b border-slate-100 shadow-xl animate-fade-in p-4 flex flex-col gap-2 max-h-[80vh] overflow-y-auto">
              {navItems.map(item => (
                <button 
                    key={item.key}
                    onClick={() => {
                        setMobileMenuOpen(false);
                        if (item.key === 'classroom') onNavigate(Page.DASHBOARD);
                        else onLandingNavigate(item.target);
                    }}
                    className="text-left px-4 py-3 rounded-xl hover:bg-slate-50 font-bold text-slate-700"
                >
                    {item.label}
                </button>
              ))}
              <div className="border-t border-slate-100 my-2 pt-2 space-y-1">
                   {subHeaderItems.map(item => (
                       <button 
                           key={item.label}
                           onClick={() => {
                               setMobileMenuOpen(false);
                               onNavigate(item.page);
                           }}
                           className="w-full text-left px-4 py-2 text-sm flex items-center gap-3 font-medium text-slate-600 hover:bg-slate-50 rounded-lg"
                       >
                           <item.icon size={16}/> {item.label}
                       </button>
                   ))}
              </div>
              {/* Mobile Language Switcher */}
              <div className="flex justify-center gap-4 p-2 border-t border-slate-100">
                  {(['EN', 'ES', 'FR'] as Language[]).map(lang => (
                      <button 
                        key={lang}
                        onClick={() => {setLanguage(lang); setMobileMenuOpen(false);}}
                        className={`px-3 py-1 rounded ${language === lang ? 'bg-[#002060] text-white' : 'bg-slate-100'}`}
                      >
                          {lang}
                      </button>
                  ))}
              </div>
              <div className="border-t border-slate-100 my-2 pt-2">
                  <button onClick={() => onNavigate(Page.PROFILE)} className="w-full text-left px-4 py-3 flex items-center gap-3 font-bold text-slate-700"><User size={18}/> My Profile</button>
                  <button onClick={() => onLandingNavigate('Inicio')} className="w-full text-left px-4 py-3 flex items-center gap-3 font-bold text-red-600"><LogOut size={18}/> Log Out</button>
              </div>
          </div>
      )}
    </header>

    {/* Sub-header for Aula Tools */}
    {isAppPage && (
        <div className="bg-white border-b border-slate-100 hidden lg:block">
            <div className="max-w-7xl mx-auto px-8">
                <div className="flex items-center gap-1">
                    {subHeaderItems.map((item) => (
                        <button
                            key={item.label}
                            onClick={() => onNavigate(item.page)}
                            className={`flex items-center gap-2 px-4 py-3 text-xs font-bold uppercase tracking-wide transition-colors border-b-2 ${
                                activePage === item.page
                                ? 'border-[#002060] text-[#002060] bg-slate-50'
                                : 'border-transparent text-slate-500 hover:text-[#002060] hover:bg-slate-50'
                            }`}
                        >
                            <item.icon size={14} />
                            {item.label}
                        </button>
                    ))}
                </div>
            </div>
        </div>
    )}
    </>
  );
};
