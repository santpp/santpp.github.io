import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#002060] text-white py-8 mt-auto">
      <div className="container mx-auto px-4 text-center text-sm opacity-80">
        <p>&copy; {new Date().getFullYear()} ASOCIM PLUS. All rights reserved.</p>
        <div className="mt-2 space-x-4">
          <a href="#" className="hover:text-teal-300">Privacy Policy</a>
          <a href="#" className="hover:text-teal-300">Terms of Service</a>
          <a href="#" className="hover:text-teal-300">Contact Support</a>
        </div>
      </div>
    </footer>
  );
};