import React, { useState, useEffect } from 'react';

interface ProgressBarProps {
  progress: number;
  className?: string;
  colorClass?: string;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({ 
  progress, 
  className = 'h-2', 
  colorClass = 'bg-[#20c997]' 
}) => {
  const [currentProgress, setCurrentProgress] = useState(0);

  useEffect(() => {
    // Use a small timeout to ensure the transition plays on mount
    const timer = setTimeout(() => {
      setCurrentProgress(progress);
    }, 100);
    
    return () => clearTimeout(timer);
  }, [progress]);

  return (
    <div className={`w-full bg-gray-100 rounded-full overflow-hidden ${className}`}>
      <div 
        className={`h-full ${colorClass} transition-all duration-1000 ease-out rounded-full`}
        style={{ width: `${currentProgress}%` }}
      />
    </div>
  );
};