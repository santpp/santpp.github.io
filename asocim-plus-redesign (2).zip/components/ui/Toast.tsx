import React, { useEffect } from 'react';
import { CheckCircle, AlertCircle, X, Info } from 'lucide-react';

export type ToastType = 'success' | 'error' | 'info';

interface ToastProps {
  message: string;
  type: ToastType;
  onClose: () => void;
}

export const Toast: React.FC<ToastProps> = ({ message, type, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(onClose, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);

  const styles = {
    success: { bg: 'bg-emerald-50', border: 'border-emerald-200', text: 'text-emerald-800', icon: <CheckCircle size={20} className="text-emerald-500" /> },
    error: { bg: 'bg-red-50', border: 'border-red-200', text: 'text-red-800', icon: <AlertCircle size={20} className="text-red-500" /> },
    info: { bg: 'bg-blue-50', border: 'border-blue-200', text: 'text-blue-800', icon: <Info size={20} className="text-blue-500" /> }
  };

  const style = styles[type];

  return (
    <div className={`fixed top-24 right-6 z-50 flex items-center gap-3 px-4 py-3 rounded-xl shadow-lg border animate-fade-in-up ${style.bg} ${style.border} min-w-[300px]`}>
      <div className="flex-shrink-0">{style.icon}</div>
      <p className={`text-sm font-medium flex-grow ${style.text}`}>{message}</p>
      <button 
        onClick={onClose} 
        className={`p-1 rounded-full hover:bg-black/5 transition-colors ${style.text}`}
      >
        <X size={16} />
      </button>
    </div>
  );
};