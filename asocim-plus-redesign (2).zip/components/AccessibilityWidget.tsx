import React from 'react';
import { Accessibility } from 'lucide-react';

export const AccessibilityWidget: React.FC = () => {
  return (
    <button 
      className="fixed bottom-6 right-6 bg-[#003e6b] hover:bg-[#002060] text-white p-3 rounded-full shadow-lg transition-transform hover:scale-110 z-40 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#002060]"
      aria-label="Accessibility options"
    >
      <Accessibility size={28} />
    </button>
  );
};