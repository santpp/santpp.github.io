
import { UserStats, Course, Module, Participant, GradeItem, CalendarEvent, Message, ForumTopic, Language } from './types';

export const BRAND_COLORS = {
  primary: '#002060', // Dark Blue
  accent: '#20c997', // Teal
  warning: '#ffc107', // Yellow
  danger: '#dc3545', // Red
  light: '#f8f9fa',
  dark: '#343a40',
};

export const TRANSLATIONS = {
    EN: {
        common: {
            addToCart: "Add to Cart",
            viewDetails: "View Details",
            select: "Select",
            popular: "Popular",
            new: "New",
            points: "Points Available",
            search: "Search",
            filter: "Filter",
            save: "Save Changes",
            cancel: "Cancel",
            edit: "Edit",
            delete: "Delete",
            back: "Back",
            send: "Send",
            loading: "Loading..."
        },
        login: {
            back: "Back to Home",
            portal: "Student Portal",
            portalDesc: "Access your personalized dashboard.",
            welcome: "Welcome Back",
            subtitle: "Please enter your details to sign in.",
            username: "Username",
            password: "Password",
            remember: "Remember me",
            forgot: "Forgot Password?",
            signIn: "Sign In",
            noAccount: "Don't have an account?",
            apply: "Apply now"
        },
        nav: {
            home: 'Home',
            courses: 'Courses',
            store: 'Store',
            classroom: 'Classroom',
            pricing: 'Pricing',
            corporate: 'Corporate',
            about: 'About Us'
        },
        subnav: {
            myCourses: "My Courses",
            notes: "Course Notes",
            allCourses: "All Courses",
            blog: "Blog",
            calendar: "Calendar",
            badges: "Badges"
        },
        dashboard: {
            welcome: "Welcome back,",
            assignments: "You have {count} assignments pending for this week. Pick up right where you left off.",
            academic: "ACADEMIC DASHBOARD",
            continue: "Continue Learning",
            progress: "Course Progress",
            quickAccess: "Quick Access",
            moreCourses: "More Courses",
            viewAll: "View All",
            next: "Next",
            inProgress: "In Progress",
            tools: {
                grades: "My Grades",
                notes: "Course Notes",
                calendar: "Calendar",
                community: "Community",
                siteHome: "Site Home",
                gradesDesc: "View Reports",
                notesDesc: "Saved Content",
                calendarDesc: "Upcoming",
                communityDesc: "Forums",
                siteHomeDesc: "Main Page"
            }
        },
        course: {
            backToDash: "Back to Dashboard",
            participants: "Participants",
            grades: "Grades",
            competencies: "Competencies",
            course: "Course Content",
            instructor: "Instructor",
            progress: "Course Progress",
            sendMessage: "Send Message",
            weeksLeft: "Weeks Left",
            locked: "This content is locked"
        },
        landing: {
            newSpots: "New Spots Available",
            heroTitleLine1: "Don't just study",
            heroTitleLine2: "English.",
            heroTitleSpan: "Live it.",
            heroSubtitle: "Forget boring grammar. Our neuro-linguistic methodology guarantees fluency in 6 months with real-world practice.",
            ctaStart: "Start Free",
            ctaDemo: "Watch Demo",
            interactiveTitle: "Interactive Learning Experience",
            interactiveSubtitle: "Experience our H5P-powered activities that make learning engaging and effective.",
            videoTitle: "Interactive Video",
            videoDesc: "Pause automatically for quizzes, clarifications, and deep-dives exactly when you need them.",
            quizTitle: "Adaptive Quizzes",
            quizDesc: "Practice vocabulary and grammar with instant feedback mechanisms.",
            join: "Join",
            students: "students",
            tutorial: {
                welcome: "Welcome to ASOCIM Plus!",
                desc: "Explore our interactive courses, visit the student store, or access your classroom directly.",
                step1: "Courses: Browse our full catalog",
                step2: "Store: Redeem points for gear",
                step3: "Classroom: Access your dashboard",
                gotIt: "Got it!"
            }
        },
        courses: {
            title: "Full Catalog",
            subtitle: "Master your skills with our specialized tracks.",
            levels: { basic: "Basic", advanced: "Advanced", exam: "Exam", specific: "Specific", intermediate: "Intermediate", all: "All Levels" },
            items: {
                c1: "English A1 Intensive",
                c2: "Business English Pro",
                c3: "TOEFL Prep",
                c4: "Medical English",
                c5: "Fluid Conversation",
                c6: "Grammar Doctor"
            },
            desc: "Lifetime access + Certification"
        },
        store: {
            title: "Student Store",
            subtitle: "Redeem your points or purchase exclusive material.",
            tags: { shipping: "Free Shipping", merch: "Merch", digital: "Digital", live: "Live", app: "App", paper: "Stationery", tech: "Tech", official: "Official" },
            items: {
                s1: "Physical Workbook A1",
                s2: "Official Hoodie",
                s3: "Flashcards Pack",
                s4: "Private Advisory",
                s5: "Pro Dictionary",
                s6: "Premium Notebook",
                s7: "HD Webcam",
                s8: "Printed Certificate"
            }
        },
        pricing: {
            title: "Simple Plans",
            subtitle: "No hidden costs. Cancel anytime.",
            monthly: { title: "Monthly", price: "29", features: ["Full Access", "1 Live Class/mo", "Basic Certification"] },
            semester: { title: "Semester", price: "149", features: ["Full Access", "Weekly Live Classes", "Priority Support", "Pro Certification"] },
            vip: { title: "VIP", price: "99", features: ["1-on-1 Coaching", "Unlimited Live Classes", "Job Interview Prep"] }
        },
        corporate: {
            title: "The language of global success.",
            subtitle: "Comprehensive platform to train high-performance teams.",
            feature1: "HR Analytics",
            feature1Desc: "Real-time dashboards to track ROI and employee engagement metrics.",
            feature2: "Personalization",
            feature2Desc: "Tailored content paths for specific industries and job roles.",
            feature3: "Flexible Costs",
            feature3Desc: "Pay-per-active-user model. Scale up or down instantly.",
            trustedBy: "Trusted by Market Leaders",
            schedule: "Schedule Meeting",
            download: "Download Case Study"
        },
        about: {
            title: "Our Mission",
            mission: "Create a world where language is not a barrier to human talent.",
            storyTitle: "The ASOCIM Story",
            story: "Founded in 2020, ASOCIM began with a simple idea: language learning should be immersive, not academic.",
            value1: "Human-Centric",
            value1Desc: "Technology serves the teacher, it doesn't replace them.",
            value2: "Global Community",
            value2Desc: "Connecting learners from 120+ countries."
        },
        calendar: {
            title: "Calendar",
            months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
            days: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
            upcoming: "Upcoming Events",
            add: "Add New Event",
            filter: "Filter by Type",
            types: { assignment: "Assignments", quiz: "Quizzes", live: "Live Classes", personal: "Personal" }
        },
        blog: {
            title: "Student Blog",
            latest: "Latest",
            popular: "Popular",
            readMore: "Read More"
        },
        badges: {
            title: "My Achievements",
            subtitle: "Track your progress and earn rewards as you learn.",
            earned: "Earned",
            points: "Points",
            rank: "Current Rank",
            unlocked: "Unlocked",
            earnedOn: "Earned on"
        },
        messages: {
            title: "Messages",
            search: "Search...",
            online: "Online",
            today: "Today",
            me: "Me",
            type: "Type a message..."
        },
        profile: {
            edit: "Edit Profile",
            about: "About",
            contact: "Contact Info",
            stats: { courses: "Courses Completed", grade: "Average Grade", hours: "Hours Learned", badges: "Badges Earned" },
            form: { photo: "Profile Photo", change: "Change", first: "First Name", last: "Last Name", bio: "Bio", email: "Email", phone: "Phone", save: "Save Changes", saving: "Saving..." }
        },
        help: {
            title: "How can we help you?",
            search: "Search articles, guides...",
            categories: ["Getting Started", "Account & Billing", "Troubleshooting"],
            faq: "Frequently Asked Questions",
            articles: "articles"
        },
        activities: {
            quiz: { submit: "Submit Quiz", completed: "Quiz Completed!", scored: "You scored", retake: "Retake", continue: "Continue" },
            assignment: { drag: "Drag & drop your file here", browse: "or click to browse", select: "Select File", submit: "Submit Assignment", uploading: "Uploading...", success: "Submitted Successfully", sent: "Your assignment has been sent for grading.", remove: "Remove" },
            resource: { download: "Download PDF", open: "Open Resource", markDone: "Mark as Done", completed: "Completed" },
            h5p: { dragTitle: "Drag the Words", task: "Task: Match the words to their definitions", check: "Check", retry: "Retry", score: "Score" }
        },
        footer: {
            desc: "The #1 English platform for modern professionals. Learn, practice, and certify your level.",
            nav: "Navigation",
            support: "Support",
            newsletter: "Newsletter",
            newsDesc: "Get free lessons every week.",
            go: "Go"
        },
        quickH5P: {
            title: "Try it without registering",
            subtitle: "Real educational technology.",
            instruction: "COMPLETE THE SENTENCE:",
            check: "Verify Answer",
            correct: "Correct! Well done.",
            incorrect: "Try again."
        },
        payment: {
            cardNo: "Card Number",
            holder: "Card Holder",
            expiry: "Expiry",
            cvc: "CVC",
            pay: "Pay Now",
            success: "Payment Successful!",
            processed: "Your order has been processed. A confirmation email has been sent to you.",
            continue: "Continue"
        }
    },
    ES: {
        common: {
            addToCart: "Añadir al Carrito",
            viewDetails: "Ver Detalles",
            select: "Seleccionar",
            popular: "Popular",
            new: "Nuevo",
            points: "Puntos Disponibles",
            search: "Buscar",
            filter: "Filtrar",
            save: "Guardar Cambios",
            cancel: "Cancelar",
            edit: "Editar",
            delete: "Borrar",
            back: "Atrás",
            send: "Enviar",
            loading: "Cargando..."
        },
        login: {
            back: "Volver al Inicio",
            portal: "Portal del Estudiante",
            portalDesc: "Accede a tu panel personalizado.",
            welcome: "Bienvenido",
            subtitle: "Por favor ingresa tus datos para iniciar sesión.",
            username: "Usuario",
            password: "Contraseña",
            remember: "Recuérdame",
            forgot: "¿Olvidaste tu contraseña?",
            signIn: "Iniciar Sesión",
            noAccount: "¿No tienes una cuenta?",
            apply: "Aplica ahora"
        },
        nav: {
            home: 'Inicio',
            courses: 'Cursos',
            store: 'Tienda',
            classroom: 'Aula',
            pricing: 'Precios',
            corporate: 'Empresa',
            about: 'Sobre Nosotros'
        },
        subnav: {
            myCourses: "Mis Cursos",
            notes: "Notas de Curso",
            allCourses: "Todos los Cursos",
            blog: "Blog",
            calendar: "Calendario",
            badges: "Insignias"
        },
        dashboard: {
            welcome: "Hola de nuevo,",
            assignments: "Tienes {count} tareas pendientes para esta semana. Continúa donde lo dejaste.",
            academic: "PANEL ACADÉMICO",
            continue: "Continuar Aprendiendo",
            progress: "Progreso del Curso",
            quickAccess: "Acceso Rápido",
            moreCourses: "Más Cursos",
            viewAll: "Ver Todos",
            next: "Siguiente",
            inProgress: "En Progreso",
            tools: {
                grades: "Mis Calificaciones",
                notes: "Notas de Curso",
                calendar: "Calendario",
                community: "Comunidad",
                siteHome: "Inicio del Sitio",
                gradesDesc: "Ver Reportes",
                notesDesc: "Contenido Guardado",
                calendarDesc: "Próximos Eventos",
                communityDesc: "Foros",
                siteHomeDesc: "Página Principal"
            }
        },
        course: {
            backToDash: "Volver al Panel",
            participants: "Participantes",
            grades: "Calificaciones",
            competencies: "Competencias",
            course: "Contenido",
            instructor: "Instructor",
            progress: "Progreso",
            sendMessage: "Enviar Mensaje",
            weeksLeft: "Semanas Restantes",
            locked: "Este contenido está bloqueado"
        },
        landing: {
            newSpots: "Nuevas Plazas Disponibles",
            heroTitleLine1: "No estudies",
            heroTitleLine2: "inglés.",
            heroTitleSpan: "Vívelo.",
            heroSubtitle: "Olvida la gramática aburrida. Nuestra metodología neuro-lingüística garantiza fluidez en 6 meses con práctica real.",
            ctaStart: "Empezar Gratis",
            ctaDemo: "Ver Demo",
            interactiveTitle: "Experiencia de Aprendizaje Interactiva",
            interactiveSubtitle: "Experimenta nuestras actividades H5P que hacen el aprendizaje efectivo.",
            videoTitle: "Video Interactivo",
            videoDesc: "Pausa automáticamente para cuestionarios y aclaraciones exactamente cuando lo necesitas.",
            quizTitle: "Cuestionarios Adaptativos",
            quizDesc: "Practica vocabulario y gramática con mecanismos de retroalimentación instantánea.",
            join: "Unete a",
            students: "estudiantes",
            tutorial: {
                welcome: "¡Bienvenido a ASOCIM Plus!",
                desc: "Explora nuestros cursos interactivos, visita la tienda o accede directamente a tu aula.",
                step1: "Cursos: Explora nuestro catálogo",
                step2: "Tienda: Canjea puntos por premios",
                step3: "Aula: Accede a tu panel principal",
                gotIt: "¡Entendido!"
            }
        },
        courses: {
            title: "Catálogo Completo",
            subtitle: "Domina tus habilidades con nuestros caminos especializados.",
            levels: { basic: "Básico", advanced: "Avanzado", exam: "Examen", specific: "Específico", intermediate: "Intermedio", all: "Todos" },
            items: {
                c1: "Inglés A1 Intensivo",
                c2: "Business English Pro",
                c3: "Preparación TOEFL",
                c4: "Inglés Médico",
                c5: "Conversación Fluida",
                c6: "Doctor Gramática"
            },
            desc: "Acceso de por vida + Certificación"
        },
        store: {
            title: "Tienda del Estudiante",
            subtitle: "Canjea tus puntos o compra material exclusivo.",
            tags: { shipping: "Envío Gratis", merch: "Merch", digital: "Digital", live: "En Vivo", app: "App", paper: "Papelería", tech: "Tech", official: "Oficial" },
            items: {
                s1: "Workbook Físico A1",
                s2: "Hoodie Oficial",
                s3: "Pack Flashcards",
                s4: "Asesoría Privada",
                s5: "Diccionario Pro",
                s6: "Notebook Premium",
                s7: "Webcam HD",
                s8: "Certificado Impreso"
            }
        },
        pricing: {
            title: "Planes Simples",
            subtitle: "Sin costos ocultos. Cancela cuando quieras.",
            monthly: { title: "Mensual", price: "29", features: ["Acceso Total", "1 Clase en Vivo/mes", "Certificación Básica"] },
            semester: { title: "Semestral", price: "149", features: ["Acceso Total", "Clases Semanales", "Soporte Prioritario", "Certificación Pro"] },
            vip: { title: "VIP", price: "99", features: ["Coaching 1-a-1", "Clases Ilimitadas", "Prep. Entrevistas"] }
        },
        corporate: {
            title: "El idioma del éxito global.",
            subtitle: "Plataforma integral para capacitar equipos de alto rendimiento.",
            feature1: "Analítica RRHH",
            feature1Desc: "Dashboards en tiempo real para medir ROI y compromiso.",
            feature2: "Personalización",
            feature2Desc: "Rutas de contenido adaptadas a industrias específicas.",
            feature3: "Costos Flexibles",
            feature3Desc: "Modelo de pago por usuario activo. Escala instantáneamente.",
            trustedBy: "Con la confianza de líderes",
            schedule: "Agendar Reunión",
            download: "Descargar Caso"
        },
        about: {
            title: "Nuestra Misión",
            mission: "Crear un mundo donde el idioma no sea una barrera para el talento humano.",
            storyTitle: "La Historia de ASOCIM",
            story: "Fundada en 2020, ASOCIM comenzó con una idea simple: aprender idiomas debe ser inmersivo, no académico.",
            value1: "Centrado en Humanos",
            value1Desc: "La tecnología sirve al profesor, no lo reemplaza.",
            value2: "Comunidad Global",
            value2Desc: "Conectando estudiantes de más de 120 países."
        },
        calendar: {
            title: "Calendario",
            months: ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"],
            days: ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"],
            upcoming: "Próximos Eventos",
            add: "Añadir Evento",
            filter: "Filtrar por Tipo",
            types: { assignment: "Tareas", quiz: "Exámenes", live: "Clases en Vivo", personal: "Personal" }
        },
        blog: {
            title: "Blog del Estudiante",
            latest: "Reciente",
            popular: "Popular",
            readMore: "Leer Más"
        },
        badges: {
            title: "Mis Logros",
            subtitle: "Sigue tu progreso y gana recompensas.",
            earned: "Ganadas",
            points: "Puntos",
            rank: "Rango Actual",
            unlocked: "Desbloqueada",
            earnedOn: "Ganada el"
        },
        messages: {
            title: "Mensajes",
            search: "Buscar...",
            online: "En línea",
            today: "Hoy",
            me: "Yo",
            type: "Escribe un mensaje..."
        },
        profile: {
            edit: "Editar Perfil",
            about: "Acerca de",
            contact: "Información de Contacto",
            stats: { courses: "Cursos Completados", grade: "Promedio", hours: "Horas Aprendidas", badges: "Insignias Ganadas" },
            form: { photo: "Foto de Perfil", change: "Cambiar", first: "Nombre", last: "Apellido", bio: "Biografía", email: "Correo", phone: "Teléfono", save: "Guardar Cambios", saving: "Guardando..." }
        },
        help: {
            title: "¿Cómo podemos ayudarte?",
            search: "Buscar artículos, guías...",
            categories: ["Empezando", "Cuenta y Facturación", "Solución de Problemas"],
            faq: "Preguntas Frecuentes",
            articles: "artículos"
        },
        activities: {
            quiz: { submit: "Enviar Examen", completed: "¡Examen Completado!", scored: "Tu puntuación", retake: "Reintentar", continue: "Continuar" },
            assignment: { drag: "Arrastra tu archivo aquí", browse: "o clic para buscar", select: "Seleccionar Archivo", submit: "Enviar Tarea", uploading: "Subiendo...", success: "¡Enviado Exitosamente!", sent: "Tu tarea ha sido enviada para calificación.", remove: "Eliminar" },
            resource: { download: "Descargar PDF", open: "Abrir Recurso", markDone: "Marcar como Hecho", completed: "Completado" },
            h5p: { dragTitle: "Arrastra las Palabras", task: "Tarea: Une las palabras con sus definiciones", check: "Comprobar", retry: "Reintentar", score: "Puntuación" }
        },
        footer: {
            desc: "La plataforma de inglés n.º 1 para profesionales modernos. Aprende, practica y certifica tu nivel.",
            nav: "Navegación",
            support: "Soporte",
            newsletter: "Boletín",
            newsDesc: "Recibe lecciones gratis cada semana.",
            go: "Ir"
        },
        quickH5P: {
            title: "Pruébalo sin registrarte",
            subtitle: "Tecnología educativa real.",
            instruction: "COMPLETA LA ORACIÓN:",
            check: "Verificar Respuesta",
            correct: "¡Correcto! Bien hecho.",
            incorrect: "Inténtalo de nuevo."
        },
        payment: {
            cardNo: "Número de Tarjeta",
            holder: "Titular",
            expiry: "Vencimiento",
            cvc: "CVC",
            pay: "Pagar Ahora",
            success: "¡Pago Exitoso!",
            processed: "Tu pedido ha sido procesado. Se ha enviado un correo de confirmación.",
            continue: "Continuar"
        }
    },
    FR: {
        common: {
            addToCart: "Ajouter au Panier",
            viewDetails: "Voir Détails",
            select: "Sélectionner",
            popular: "Populaire",
            new: "Nouveau",
            points: "Points Disponibles",
            search: "Rechercher",
            filter: "Filtrer",
            save: "Enregistrer",
            cancel: "Annuler",
            edit: "Modifier",
            delete: "Supprimer",
            back: "Retour",
            send: "Envoyer",
            loading: "Chargement..."
        },
        login: {
            back: "Retour à l'Accueil",
            portal: "Portail Étudiant",
            portalDesc: "Accédez à votre tableau de bord.",
            welcome: "Bon retour",
            subtitle: "Veuillez entrer vos coordonnées pour vous connecter.",
            username: "Nom d'utilisateur",
            password: "Mot de passe",
            remember: "Se souvenir de moi",
            forgot: "Mot de passe oublié ?",
            signIn: "Se Connecter",
            noAccount: "Pas de compte ?",
            apply: "Postuler"
        },
        nav: {
            home: 'Accueil',
            courses: 'Cours',
            store: 'Boutique',
            classroom: 'Classe',
            pricing: 'Tarifs',
            corporate: 'Entreprise',
            about: 'À Propos'
        },
        subnav: {
            myCourses: "Mes Cours",
            notes: "Notes de Cours",
            allCourses: "Tous les Cours",
            blog: "Blog",
            calendar: "Calendrier",
            badges: "Badges"
        },
        dashboard: {
            welcome: "Bon retour,",
            assignments: "Vous avez {count} devoirs en attente pour cette semaine.",
            academic: "TABLEAU DE BORD ACADÉMIQUE",
            continue: "Continuer",
            progress: "Progression",
            quickAccess: "Accès Rapide",
            moreCourses: "Plus de Cours",
            viewAll: "Voir Tout",
            next: "Suivant",
            inProgress: "En Cours",
            tools: {
                grades: "Mes Notes",
                notes: "Notes",
                calendar: "Calendrier",
                community: "Communauté",
                siteHome: "Accueil Site",
                gradesDesc: "Voir Rapports",
                notesDesc: "Contenu Sauvegardé",
                calendarDesc: "À Venir",
                communityDesc: "Forums",
                siteHomeDesc: "Page Principale"
            }
        },
        course: {
            backToDash: "Retour au Tableau de Bord",
            participants: "Participants",
            grades: "Notes",
            competencies: "Compétences",
            course: "Contenu",
            instructor: "Instructeur",
            progress: "Progression",
            sendMessage: "Envoyer Message",
            weeksLeft: "Semaines Restantes",
            locked: "Ce contenu est verrouillé"
        },
        landing: {
            newSpots: "Nouvelles Places Disponibles",
            heroTitleLine1: "N'étudiez pas",
            heroTitleLine2: "l'anglais.",
            heroTitleSpan: "Vivez-le.",
            heroSubtitle: "Oubliez la grammaire ennuyeuse. Notre méthodologie garantit la fluidité en 6 mois avec une pratique réelle.",
            ctaStart: "Commencer",
            ctaDemo: "Voir Démo",
            interactiveTitle: "Expérience d'Apprentissage Interactive",
            interactiveSubtitle: "Découvrez nos activités H5P qui rendent l'apprentissage engageant.",
            videoTitle: "Vidéo Interactive",
            videoDesc: "Pause automatique pour quiz et clarifications exactement quand vous en avez besoin.",
            quizTitle: "Quiz Adaptatifs",
            quizDesc: "Pratiquez le vocabulaire et la grammaire avec un retour instantané.",
            join: "Rejoignez",
            students: "étudiants",
            tutorial: {
                welcome: "Bienvenue sur ASOCIM Plus !",
                desc: "Explorez nos cours interactifs, visitez la boutique ou accédez directement à votre classe.",
                step1: "Cours : Parcourez notre catalogue",
                step2: "Boutique : Échangez des points",
                step3: "Classe : Accédez à votre tableau de bord",
                gotIt: "Compris !"
            }
        },
        courses: {
            title: "Catalogue Complet",
            subtitle: "Maîtrisez vos compétences avec nos parcours spécialisés.",
            levels: { basic: "Basique", advanced: "Avancé", exam: "Examen", specific: "Spécifique", intermediate: "Intermédiaire", all: "Tous Niveaux" },
            items: {
                c1: "Anglais A1 Intensif",
                c2: "Business English Pro",
                c3: "Préparation TOEFL",
                c4: "Anglais Médical",
                c5: "Conversation Fluida",
                c6: "Docteur Grammaire"
            },
            desc: "Accès à vie + Certification"
        },
        store: {
            title: "Boutique Étudiante",
            subtitle: "Échangez vos points ou achetez du matériel exclusif.",
            tags: { shipping: "Livraison Gratuite", merch: "Merch", digital: "Numérique", live: "En Direct", app: "App", paper: "Papeterie", tech: "Tech", official: "Officiel" },
            items: {
                s1: "Cahier d'Exercices A1",
                s2: "Sweat à Capuche",
                s3: "Pack Flashcards",
                s4: "Conseil Privé",
                s5: "Dictionnaire Pro",
                s6: "Carnet Premium",
                s7: "Webcam HD",
                s8: "Certificat Imprimé"
            }
        },
        pricing: {
            title: "Tarifs Simples",
            subtitle: "Pas de frais cachés. Annulez à tout moment.",
            monthly: { title: "Mensual", price: "29", features: ["Accès Complet", "1 Cours en Direct/mois", "Certification de Base"] },
            semester: { title: "Semestriel", price: "149", features: ["Accès Complet", "Cours Hebdomadaires", "Support Prioritaire", "Certification Pro"] },
            vip: { title: "VIP", price: "99", features: ["Coaching 1-à-1", "Cours Illimités", "Prép. Entretien"] }
        },
        corporate: {
            title: "La langue du succès mondial.",
            subtitle: "Plateforme complète pour former des équipes performantes.",
            feature1: "Analytique RH",
            feature1Desc: "Tableaux de bord en temps réel pour suivre le ROI.",
            feature2: "Personnalisation",
            feature2Desc: "Parcours de contenu adaptés aux secteurs spécifiques.",
            feature3: "Coûts Flexibles",
            feature3Desc: "Modèle de paiement par utilisateur actif.",
            trustedBy: "Reconnu par les leaders",
            schedule: "Planifier Réunion",
            download: "Télécharger l'Étude"
        },
        about: {
            title: "Notre Mission",
            mission: "Créer un monde où la langue n'est pas un obstacle au talent humain.",
            storyTitle: "L'Histoire d'ASOCIM",
            story: "Fondée en 2020, ASOCIM a commencé avec une idée simple : l'apprentissage des langues doit être immersif.",
            value1: "Centré sur l'Humain",
            value1Desc: "La technologie sert l'enseignant, elle ne le remplace pas.",
            value2: "Communauté Mondiale",
            value2Desc: "Connecter des apprenants de plus de 120 pays."
        },
        calendar: {
            title: "Calendrier",
            months: ["Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"],
            days: ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"],
            upcoming: "Événements à Venir",
            add: "Ajouter Événement",
            filter: "Filtrer par Type",
            types: { assignment: "Devoirs", quiz: "Quiz", live: "Cours en Direct", personal: "Personnel" }
        },
        blog: {
            title: "Blog Étudiant",
            latest: "Récent",
            popular: "Populaire",
            readMore: "Lire la Suite"
        },
        badges: {
            title: "Mes Réalisations",
            subtitle: "Suivez vos progrès et gagnez des récompenses.",
            earned: "Gagnés",
            points: "Points",
            rank: "Rang Actuel",
            unlocked: "Débloqué",
            earnedOn: "Gagné le"
        },
        messages: {
            title: "Messages",
            search: "Rechercher...",
            online: "En ligne",
            today: "Aujourd'hui",
            me: "Moi",
            type: "Écrivez un message..."
        },
        profile: {
            edit: "Modifier Profil",
            about: "À propos",
            contact: "Coordonnées",
            stats: { courses: "Cours Terminés", grade: "Note Moyenne", hours: "Heures Apprises", badges: "Badges Gagnés" },
            form: { photo: "Photo de Profil", change: "Modifier", first: "Prénom", last: "Nom", bio: "Bio", email: "E-mail", phone: "Téléphone", save: "Enregistrer", saving: "Enregistrement..." }
        },
        help: {
            title: "Comment pouvons-nous vous aider ?",
            search: "Rechercher articles, guides...",
            categories: ["Démarrage", "Compte & Facturation", "Dépannage"],
            faq: "Foire Aux Questions",
            articles: "articles"
        },
        activities: {
            quiz: { submit: "Soumettre Quiz", completed: "Quiz Terminé !", scored: "Votre score", retake: "Refaire", continue: "Continuer" },
            assignment: { drag: "Glissez votre fichier ici", browse: "ou cliquez pour parcourir", select: "Sélectionner Fichier", submit: "Soumettre Devoir", uploading: "Téléchargement...", success: "Soumis avec Succès !", sent: "Votre devoir a été envoyé pour notation.", remove: "Supprimer" },
            resource: { download: "Télécharger PDF", open: "Ouvrir Ressource", markDone: "Marquer comme Fait", completed: "Terminé" },
            h5p: { dragTitle: "Glissez les Mots", task: "Tâche : Associez les mots à leurs définitions", check: "Vérifier", retry: "Réessayer", score: "Score" }
        },
        footer: {
            desc: "La plateforme d'anglais n°1 pour les professionnels modernes. Apprenez, pratiquez et certifiez votre niveau.",
            nav: "Navigation",
            support: "Support",
            newsletter: "Newsletter",
            newsDesc: "Recevez des leçons gratuites chaque semaine.",
            go: "Aller"
        },
        quickH5P: {
            title: "Essayez sans inscription",
            subtitle: "Vraie technologie éducative.",
            instruction: "COMPLÉTEZ LA PHRASE :",
            check: "Vérifier Réponse",
            correct: "Correct ! Bien joué.",
            incorrect: "Réessayez."
        },
        payment: {
            cardNo: "Numéro de Carte",
            holder: "Titulaire",
            expiry: "Expiration",
            cvc: "CVC",
            pay: "Payer Maintenant",
            success: "Paiement Réussi !",
            processed: "Votre commande a été traitée. Un e-mail de confirmation vous a été envoyé.",
            continue: "Continuer"
        }
    }
};

export const MOCK_USER_STATS: UserStats[] = [
  { label: 'Usuarios', value: 67, color: '#2563eb', total: 100 },
  { label: 'Activos', value: 43, color: '#20c997', total: 67 },
  { label: 'Online', value: 1, color: '#fbbf24', total: 67 },
];

export const MOCK_COURSES: Course[] = [
  {
    id: 'c1',
    title: 'ASOCIM Plus - OFFline',
    thumbnail: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=800&auto=format&fit=crop',
    progress: 30,
    category: 'Asincrona',
    isFavorite: true
  },
  {
    id: 'c2',
    title: 'Clinical Research Fundamentals',
    thumbnail: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?q=80&w=800&auto=format&fit=crop',
    progress: 75,
    category: 'Sincrona'
  },
  {
    id: 'c3',
    title: 'Bioethics and Safety',
    thumbnail: 'https://images.unsplash.com/photo-1532938911079-1b06ac7ceec7?q=80&w=800&auto=format&fit=crop',
    progress: 0,
    category: 'Sincrona'
  }
];

export const MOCK_MODULES: Module[] = [
  {
    id: 'm1',
    title: 'Module 1: Introduction to ASOCIM',
    activities: [
        { id: 'a1', type: 'pdf', title: 'VG 1 - Guide', isCompleted: true, fileUrl: '/docs/guide.pdf', content: 'Download the comprehensive study guide for Module 1.' },
        { id: 'a2', type: 'link', title: 'Vocabulary Tutorial', isCompleted: true, linkUrl: 'https://youtube.com', content: 'Watch this 10-minute video tutorial covering essential medical vocabulary.' },
        { id: 'a3', type: 'link', title: 'Grammar Tutorial', isCompleted: false, linkUrl: 'https://grammar-resource.com', content: 'External resource link for advanced grammar rules.' },
        { id: 'a4', type: 'h5p-drag', title: 'Vocabulary Matching (H5P)', isCompleted: false },
    ]
  },
  {
    id: 'm2',
    title: 'Evaluation Activities',
    activities: [
        { 
            id: 'q1', type: 'quiz', title: 'Quiz M1 VG1', isCompleted: false, 
            questions: [
                { id: 'q1_1', text: 'What is the primary goal of ASOCIM?', options: ['Research', 'Teaching', 'Both', 'None'], correct: 2 },
                { id: 'q1_2', text: 'Which level corresponds to "Advanced"?', options: ['A1', 'B1', 'C1', 'A2'], correct: 2 },
                { id: 'q1_3', text: 'True or False: The course is purely theoretical.', options: ['True', 'False'], correct: 1 }
            ]
        },
        { 
            id: 'q2', type: 'quiz', title: 'Vocabulary Activity M1 VG1', isCompleted: true,
            questions: [
                 { id: 'q2_1', text: 'Select the synonym for "Improve"', options: ['Worsen', 'Enhance', 'Stagnate', 'Break'], correct: 1 },
                 { id: 'q2_2', text: 'Which word implies "working together"?', options: ['Competition', 'Collaboration', 'Isolation', 'Division'], correct: 1 }
            ]
        },
        { 
            id: 'q3', type: 'assignment', title: 'Final Essay', isCompleted: false, isLocked: false,
            content: 'Write a 300-word essay on "The Impact of Technology in Modern Language Learning". Please upload as PDF.'
        },
    ]
  }
];

export const MOCK_PARTICIPANTS: Participant[] = [
    { id: 'p1', name: 'Dr. Sarah Jenning', role: 'Teacher', lastAccess: 'Now', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330', email: 'sarah.j@asocim.org' },
    { id: 'p2', name: 'Michael Chen', role: 'Student', lastAccess: '5 min ago', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d', email: 'm.chen@student.com' },
    { id: 'p3', name: 'Emily Davis', role: 'Student', lastAccess: '1 day ago', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80', email: 'emily.d@student.com' },
    { id: 'p4', name: 'James Wilson', role: 'Student', lastAccess: '2 hours ago', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e', email: 'j.wilson@student.com' },
];

export const MOCK_GRADES: GradeItem[] = [
    { id: 'g1', courseName: 'ASOCIM Plus - OFFline', item: 'Quiz M1 VG1', grade: '95.00', range: '0-100', percentage: '95%' },
    { id: 'g2', courseName: 'ASOCIM Plus - OFFline', item: 'Vocabulary Activity', grade: '88.50', range: '0-100', percentage: '88.5%' },
    { id: 'g3', courseName: 'Clinical Research', item: 'Midterm Exam', grade: 'A', range: 'F-A', percentage: '92%' },
];

export const MOCK_EVENTS: CalendarEvent[] = [
    { id: 'e1', title: 'Final Essay Submission', date: '2023-10-25', time: '23:59', type: 'assignment', courseId: 'c1' },
    { id: 'e2', title: 'Live Q&A Session', date: '2023-10-26', time: '14:00', type: 'meeting', courseId: 'c2' },
    { id: 'e3', title: 'Module 2 Quiz', date: '2023-10-28', time: '10:00', type: 'quiz', courseId: 'c1' },
];

export const MOCK_MESSAGES: Message[] = [
    { id: 'msg1', sender: 'Dr. Sarah Jenning', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330', text: 'Please remember to review the safety guidelines before tomorrow.', timestamp: '10:30 AM', unread: true },
    { id: 'msg2', sender: 'Michael Chen', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d', text: 'Hey, did you finish the vocabulary quiz?', timestamp: 'Yesterday', unread: false },
];

export const MOCK_TOPICS: ForumTopic[] = [
    { id: 't1', title: 'Welcome Introductions', author: 'Admin', replies: 45, views: 320, lastPost: 'Today', category: 'General' },
    { id: 't2', title: 'Questions about Module 1', author: 'Emily Davis', replies: 12, views: 85, lastPost: '2 hours ago', category: 'Course Q&A' },
    { id: 't3', title: 'Study Group Formation', author: 'James Wilson', replies: 8, views: 56, lastPost: 'Yesterday', category: 'Social' },
];