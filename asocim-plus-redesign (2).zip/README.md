
# ASOCIM PLUS - React LMS Redesign

This project is a modern, high-fidelity redesign of a Learning Management System (LMS) resembling Moodle, built with React and Tailwind CSS.

## Key Features

### 1. H5P Activity Simulations
*   **Interactive Video**: Located in `views/Landing.tsx`. Simulates a video player with overlay questions.
*   **Drag & Drop**: Located in `views/CourseView.tsx`. A fully functional drag-and-drop vocabulary exercise.
*   **Fill in the Blanks**: Located in `views/Landing.tsx`.

### 2. Commerce & Payment
*   **Shopping Cart**: Manages state in `views/Landing.tsx`.
*   **Credit Card Simulation**: A realistic credit card form with visual feedback in `views/Landing.tsx`.

### 3. Internationalization (i18n)
*   **Language Switcher**: Located in `components/Header.tsx`. Switches between EN, ES, and FR.
*   **Translations**: All text strings are stored in `constants.ts` under `TRANSLATIONS`.

### 4. UI/UX Improvements
*   **White Input Fields**: All text inputs in Login, Profile, and Messages are styled with `bg-white` for contrast against dark backgrounds.
*   **Tutorial Overlay**: A dismissible popup for new users in `views/Landing.tsx`.
*   **Custom Username**: The login name persists across the dashboard and profile.

## File Structure & Responsibilities

### Core
*   `App.tsx`: The main entry point. Handles global state (User Name, Language, Current Page) and Routing.
*   `types.ts`: TypeScript definitions for Course, Activity, Language, etc.
*   `constants.ts`: Mock data (Courses, Users) and Translation dictionaries.

### Views
*   `views/Login.tsx`: Login screen with cinematic background. Accepts custom usernames.
*   `views/Landing.tsx`: The public front-page. Contains the Store, Course Catalog, Corporate info, and H5P demos.
*   `views/Dashboard.tsx`: The main user hub after logging in. Shows active courses and quick tools.
*   `views/CourseView.tsx`: The actual classroom interface. Handles tabs (Grades, Participants) and renders Activities (PDF, Quiz, H5P).
*   `views/SecondaryViews.tsx`: Contains smaller pages like Profile, Edit Profile, Calendar, and Messages.

### Components
*   `components/Header.tsx`: The top navigation bar. Contains Notifications, User Profile, Language Switcher, and Sub-navigation.
*   `components/ui/Card.tsx`: Reusable card container.
*   `components/ui/ProgressBar.tsx`: Animated progress bar.
*   `components/ui/Toast.tsx`: Notification popups.

## How to Customize
*   **To add a new language**: Update `TRANSLATIONS` in `constants.ts`.
*   **To change course content**: Modify `MOCK_COURSES` and `MOCK_MODULES` in `constants.ts`.
*   **To modify styles**: Edit Tailwind classes in the specific component files.
