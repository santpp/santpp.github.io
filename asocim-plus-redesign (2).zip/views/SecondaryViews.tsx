
import React, { useState } from 'react';
import { MOCK_GRADES, MOCK_EVENTS, MOCK_MESSAGES, TRANSLATIONS } from '../constants';
import { Card } from '../components/ui/Card';
import { 
    Calendar as CalendarIcon, MessageSquare, Users, Settings, Mail, Search, 
    Filter, MoreVertical, Clock, Save, X, AlertCircle, Phone, HelpCircle, ChevronDown,
    FileText, Award, Database, PenTool, Share2, Heart, ArrowRight, Star, Zap, Play, Plus,
    LayoutGrid, Image as ImageIcon, Video, File, Link, Send, ChevronRight, Globe, Lock,
    ChevronLeft, MapPin
} from 'lucide-react';
import { H5PInteractiveVideo } from './Landing';
import { Language } from '../types';

interface ViewProps {
    language: Language;
}

// Placeholder Views
export const GradesView: React.FC<ViewProps> = ({language}) => <div className="p-8 text-2xl font-bold text-slate-800">{TRANSLATIONS[language].dashboard.tools.gradesDesc}</div>;
export const CommunityView: React.FC<ViewProps> = ({language}) => <div className="p-8 text-2xl font-bold text-slate-800">{TRANSLATIONS[language].dashboard.tools.communityDesc}</div>;
export const ContentBankView: React.FC<ViewProps> = () => <div className="p-8"><h2 className="text-2xl font-bold text-[#002060] mb-6">Content Bank Preview</h2><H5PInteractiveVideo /></div>;

export const CalendarView: React.FC<ViewProps> = ({ language }) => {
    const [currentDate, setCurrentDate] = useState(new Date());
    const [selectedDate, setSelectedDate] = useState<string | null>(null);
    const t = TRANSLATIONS[language].calendar;

    const getDaysInMonth = (date: Date) => {
        const year = date.getFullYear();
        const month = date.getMonth();
        const days = new Date(year, month + 1, 0).getDate();
        const firstDay = new Date(year, month, 1).getDay();
        return { days, firstDay, month, year };
    };

    const { days, firstDay, month, year } = getDaysInMonth(currentDate);
    
    const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1));
    const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1));

    const todayStr = new Date().toISOString().split('T')[0];

    const getEventsForDay = (day: number) => {
        const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        return MOCK_EVENTS.filter(e => e.date === dateStr);
    };

    return (
        <div className="max-w-7xl mx-auto px-6 py-8 animate-fade-in-up">
            <div className="grid lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 bg-white rounded-3xl shadow-lg border border-slate-100 overflow-hidden p-6">
                    <div className="flex justify-between items-center mb-8">
                        <h2 className="text-2xl font-bold text-[#002060]">
                            {t.months[month]} {year}
                        </h2>
                        <div className="flex gap-2">
                            <button onClick={prevMonth} className="p-2 hover:bg-slate-100 rounded-full transition-colors"><ChevronLeft /></button>
                            <button onClick={nextMonth} className="p-2 hover:bg-slate-100 rounded-full transition-colors"><ChevronRight /></button>
                        </div>
                    </div>

                    <div className="grid grid-cols-7 gap-2 text-center mb-4">
                        {t.days.map(d => (
                            <div key={d} className="text-xs font-bold text-slate-400 uppercase tracking-wider">{d}</div>
                        ))}
                    </div>

                    <div className="grid grid-cols-7 gap-2">
                        {Array.from({ length: firstDay }).map((_, i) => (
                            <div key={`empty-${i}`} className="h-24 md:h-32 bg-slate-50/50 rounded-xl"></div>
                        ))}
                        {Array.from({ length: days }).map((_, i) => {
                            const day = i + 1;
                            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                            const events = getEventsForDay(day);
                            const isToday = dateStr === todayStr;

                            return (
                                <div 
                                    key={day} 
                                    onClick={() => setSelectedDate(dateStr)}
                                    className={`h-24 md:h-32 p-2 rounded-xl border transition-all cursor-pointer hover:shadow-md relative group ${isToday ? 'bg-blue-50 border-blue-200' : 'bg-white border-slate-100 hover:border-blue-200'}`}
                                >
                                    <div className={`text-sm font-bold mb-1 ${isToday ? 'text-blue-600' : 'text-slate-700'}`}>{day}</div>
                                    <div className="space-y-1 overflow-hidden max-h-[calc(100%-24px)]">
                                        {events.map(ev => (
                                            <div key={ev.id} className={`text-[10px] px-1.5 py-0.5 rounded truncate ${
                                                ev.type === 'assignment' ? 'bg-red-100 text-red-700' : 
                                                ev.type === 'quiz' ? 'bg-amber-100 text-amber-700' : 
                                                'bg-blue-100 text-blue-700'
                                            }`}>
                                                {ev.title}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>

                <div className="space-y-6">
                    <div className="bg-[#002060] text-white rounded-3xl p-6 shadow-xl">
                        <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
                            <Clock size={20} className="text-blue-300"/> {t.upcoming}
                        </h3>
                        <div className="space-y-4">
                            {MOCK_EVENTS.slice(0, 3).map(ev => (
                                <div key={ev.id} className="bg-white/10 p-4 rounded-xl backdrop-blur-sm border border-white/10 hover:bg-white/20 transition-colors cursor-pointer">
                                    <div className="flex justify-between items-start mb-1">
                                        <span className="font-bold text-sm line-clamp-1">{ev.title}</span>
                                        <span className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                                            ev.type === 'assignment' ? 'bg-red-500 text-white' : 'bg-blue-500 text-white'
                                        }`}>{ev.type}</span>
                                    </div>
                                    <div className="flex items-center gap-2 text-xs text-blue-200">
                                        <CalendarIcon size={12}/> {ev.date} • {ev.time}
                                    </div>
                                </div>
                            ))}
                        </div>
                        <button className="w-full mt-6 py-3 bg-white text-[#002060] rounded-xl font-bold text-sm hover:bg-blue-50 transition-colors">
                            {t.add}
                        </button>
                    </div>

                    <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
                        <h3 className="font-bold text-slate-800 mb-4">{t.filter}</h3>
                        <div className="space-y-2">
                            {[t.types.assignment, t.types.quiz, t.types.live, t.types.personal].map(type => (
                                <label key={type} className="flex items-center gap-3 p-3 hover:bg-slate-50 rounded-xl cursor-pointer transition-colors">
                                    <div className={`w-4 h-4 rounded border flex items-center justify-center border-slate-300`}>
                                        <div className="w-2.5 h-2.5 bg-[#002060] rounded-sm opacity-0 hover:opacity-100"></div>
                                    </div>
                                    <span className="text-sm font-medium text-slate-600">{type}</span>
                                </label>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export const BlogView: React.FC<ViewProps> = ({ language }) => {
    const t = TRANSLATIONS[language].blog;
    const posts = [
        { id: 1, title: "5 Tips to Master Business English", category: "Tips & Tricks", date: "Oct 15, 2023", image: "https://images.unsplash.com/photo-1557804506-669a67965ba0?w=600&auto=format&fit=crop", excerpt: "Learn the key phrases that will make you sound more professional in your next meeting." },
        { id: 2, title: "Understanding Medical Terminology", category: "Academic", date: "Oct 12, 2023", image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=600&auto=format&fit=crop", excerpt: "A deep dive into the roots and suffixes used in modern clinical research documentation." },
        { id: 3, title: "Student Success Story: Maria's Journey", category: "Community", date: "Oct 08, 2023", image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=600&auto=format&fit=crop", excerpt: "How Maria went from A2 to C1 in just 6 months using our immersive platform." },
        { id: 4, title: "The Future of Remote Learning", category: "Tech", date: "Oct 01, 2023", image: "https://images.unsplash.com/photo-1501504905252-473c47e087f8?w=600&auto=format&fit=crop", excerpt: "Why asynchronous learning combined with live coaching is the most effective model." }
    ];

    return (
        <div className="max-w-7xl mx-auto px-6 py-8 animate-fade-in-up">
            <div className="flex justify-between items-center mb-8">
                <h1 className="text-3xl font-bold text-[#002060]">{t.title}</h1>
                <div className="flex gap-2">
                    <button className="bg-white border border-slate-200 px-4 py-2 rounded-lg text-sm font-bold text-slate-600 hover:bg-slate-50">{t.latest}</button>
                    <button className="bg-white border border-slate-200 px-4 py-2 rounded-lg text-sm font-bold text-slate-600 hover:bg-slate-50">{t.popular}</button>
                </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {posts.map(post => (
                    <div key={post.id} className="bg-white rounded-2xl overflow-hidden shadow-sm border border-slate-100 hover:shadow-lg transition-all group cursor-pointer">
                        <div className="h-48 overflow-hidden relative">
                            <img src={post.image} alt={post.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"/>
                            <div className="absolute top-3 left-3 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-[#002060] uppercase">{post.category}</div>
                        </div>
                        <div className="p-6">
                            <div className="flex items-center gap-2 text-slate-400 text-xs mb-3">
                                <Clock size={14} /> {post.date}
                            </div>
                            <h3 className="text-xl font-bold text-slate-800 mb-3 group-hover:text-[#002060] transition-colors">{post.title}</h3>
                            <p className="text-slate-500 text-sm mb-4 line-clamp-2">{post.excerpt}</p>
                            <div className="flex items-center text-[#002060] font-bold text-sm gap-1 group-hover:gap-2 transition-all">
                                {t.readMore} <ArrowRight size={16} />
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export const BadgesView: React.FC<ViewProps> = ({ language }) => {
    const t = TRANSLATIONS[language].badges;
    const badges = [
        { id: 1, name: "First Steps", desc: "Completed Module 1", icon: <Zap size={24} />, color: "bg-yellow-100 text-yellow-600", unlocked: true, progress: 100 },
        { id: 2, name: "Vocabulary Master", desc: "Scored 100% on Vocab Quiz", icon: <Star size={24} />, color: "bg-blue-100 text-blue-600", unlocked: true, progress: 100 },
        { id: 3, name: "Perfect Attendance", desc: "Attended 5 Live Classes", icon: <CalendarIcon size={24} />, color: "bg-green-100 text-green-600", unlocked: true, progress: 100 },
        { id: 4, name: "Social Butterfly", desc: "Posted 10 times in Community", icon: <MessageSquare size={24} />, color: "bg-purple-100 text-purple-600", unlocked: false, progress: 40 },
        { id: 5, name: "Course Finisher", desc: "Complete the full course", icon: <Award size={24} />, color: "bg-red-100 text-red-600", unlocked: false, progress: 30 },
        { id: 6, name: "Helper", desc: "Answered a student question", icon: <Heart size={24} />, color: "bg-pink-100 text-pink-600", unlocked: false, progress: 0 },
    ];

    return (
        <div className="max-w-7xl mx-auto px-6 py-8 animate-fade-in-up">
            <div className="bg-gradient-to-r from-[#002060] to-[#003380] rounded-3xl p-8 text-white mb-12 relative overflow-hidden">
                <div className="relative z-10">
                    <h1 className="text-3xl font-bold mb-2">{t.title}</h1>
                    <p className="text-blue-100">{t.subtitle}</p>
                    <div className="mt-6 flex gap-8">
                        <div>
                            <span className="text-3xl font-bold block">3</span>
                            <span className="text-xs uppercase tracking-wide opacity-70">{t.earned}</span>
                        </div>
                        <div>
                            <span className="text-3xl font-bold block">1250</span>
                            <span className="text-xs uppercase tracking-wide opacity-70">{t.points}</span>
                        </div>
                        <div>
                            <span className="text-3xl font-bold block text-yellow-400">Level 5</span>
                            <span className="text-xs uppercase tracking-wide opacity-70">{t.rank}</span>
                        </div>
                    </div>
                </div>
                <Award className="absolute right-0 bottom-0 text-white/5 w-64 h-64 -mr-8 -mb-8" />
            </div>

            <div className="grid md:grid-cols-3 gap-6">
                {badges.map(badge => (
                    <div key={badge.id} className={`bg-white p-6 rounded-2xl border ${badge.unlocked ? 'border-slate-100 shadow-sm' : 'border-dashed border-slate-200 bg-slate-50/50'}`}>
                        <div className="flex items-start justify-between mb-4">
                            <div className={`w-14 h-14 rounded-full flex items-center justify-center ${badge.unlocked ? badge.color : 'bg-slate-200 text-slate-400'}`}>
                                {badge.icon}
                            </div>
                            {badge.unlocked ? (
                                <span className="bg-green-100 text-green-700 text-[10px] font-bold px-2 py-1 rounded uppercase">{t.unlocked}</span>
                            ) : (
                                <Lock size={16} className="text-slate-300" />
                            )}
                        </div>
                        <h3 className={`font-bold text-lg mb-1 ${badge.unlocked ? 'text-slate-800' : 'text-slate-500'}`}>{badge.name}</h3>
                        <p className="text-sm text-slate-500 mb-4">{badge.desc}</p>
                        
                        {!badge.unlocked && (
                            <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                                <div className="bg-[#002060] h-full rounded-full" style={{width: `${badge.progress}%`}}></div>
                            </div>
                        )}
                        {badge.unlocked && <div className="text-xs text-slate-400">{t.earnedOn} Oct 20, 2023</div>}
                    </div>
                ))}
            </div>
        </div>
    );
};

export const MessagesView: React.FC<ViewProps> = ({ language }) => {
    const [selectedChat, setSelectedChat] = useState<string | null>(MOCK_MESSAGES[0].id);
    const [newMessage, setNewMessage] = useState('');
    const t = TRANSLATIONS[language].messages;

    return (
        <div className="max-w-7xl mx-auto px-4 lg:px-8 py-8 h-[calc(100vh-6rem)]">
            <div className="bg-white rounded-3xl shadow-lg border border-slate-100 overflow-hidden h-full flex">
                <div className="w-full md:w-80 border-r border-slate-100 flex flex-col">
                    <div className="p-6 border-b border-slate-100">
                        <h2 className="text-xl font-bold text-[#002060] mb-4">{t.title}</h2>
                        <div className="relative">
                            <Search className="absolute left-3 top-3 text-slate-400" size={18} />
                            <input 
                                type="text" 
                                placeholder={t.search} 
                                className="w-full pl-10 py-2.5 bg-white border border-slate-200 rounded-xl text-sm outline-none focus:ring-2 focus:ring-blue-100 text-slate-900"
                            />
                        </div>
                    </div>
                    <div className="flex-grow overflow-y-auto">
                        {MOCK_MESSAGES.map(msg => (
                            <button 
                                key={msg.id}
                                onClick={() => setSelectedChat(msg.id)}
                                className={`w-full p-4 flex gap-3 hover:bg-slate-50 transition-colors text-left ${selectedChat === msg.id ? 'bg-blue-50/50 border-l-4 border-[#002060]' : 'border-l-4 border-transparent'}`}
                            >
                                <div className="relative">
                                    <img src={msg.avatar} className="w-12 h-12 rounded-full object-cover" alt="User" />
                                    {msg.unread && <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>}
                                </div>
                                <div className="flex-grow min-w-0">
                                    <div className="flex justify-between items-baseline mb-1">
                                        <span className={`font-bold truncate ${msg.unread ? 'text-[#002060]' : 'text-slate-700'}`}>{msg.sender}</span>
                                        <span className="text-xs text-slate-400">{msg.timestamp}</span>
                                    </div>
                                    <p className="text-sm text-slate-500 truncate">{msg.text}</p>
                                </div>
                            </button>
                        ))}
                    </div>
                </div>

                <div className="hidden md:flex flex-1 flex-col bg-slate-50/30">
                    {selectedChat ? (
                        <>
                            <div className="p-6 border-b border-slate-100 bg-white flex justify-between items-center">
                                <div className="flex items-center gap-3">
                                    <img src={MOCK_MESSAGES.find(m => m.id === selectedChat)?.avatar} className="w-10 h-10 rounded-full object-cover" alt="User" />
                                    <div>
                                        <h3 className="font-bold text-slate-800">{MOCK_MESSAGES.find(m => m.id === selectedChat)?.sender}</h3>
                                        <span className="text-xs text-green-600 font-medium flex items-center gap-1">
                                            <div className="w-2 h-2 bg-green-500 rounded-full"></div> {t.online}
                                        </span>
                                    </div>
                                </div>
                                <button className="p-2 hover:bg-slate-100 rounded-full text-slate-400">
                                    <MoreVertical size={20} />
                                </button>
                            </div>
                            
                            <div className="flex-grow p-6 overflow-y-auto space-y-6">
                                <div className="flex justify-center">
                                    <span className="text-xs font-bold text-slate-400 bg-slate-100 px-3 py-1 rounded-full">{t.today}</span>
                                </div>
                                <div className="flex gap-4">
                                    <img src={MOCK_MESSAGES.find(m => m.id === selectedChat)?.avatar} className="w-8 h-8 rounded-full object-cover mt-1" alt="User" />
                                    <div className="bg-white p-4 rounded-2xl rounded-tl-none shadow-sm border border-slate-100 max-w-md">
                                        <p className="text-slate-700 text-sm leading-relaxed">{MOCK_MESSAGES.find(m => m.id === selectedChat)?.text}</p>
                                        <span className="text-[10px] text-slate-400 mt-2 block">10:30 AM</span>
                                    </div>
                                </div>
                                <div className="flex gap-4 flex-row-reverse">
                                    <div className="w-8 h-8 rounded-full bg-[#002060] flex items-center justify-center text-white font-bold text-xs mt-1">{t.me}</div>
                                    <div className="bg-[#002060] text-white p-4 rounded-2xl rounded-tr-none shadow-md max-w-md">
                                        <p className="text-sm leading-relaxed">Thanks for letting me know! I'll check it right away.</p>
                                        <span className="text-[10px] text-blue-200 mt-2 block text-right">10:32 AM</span>
                                    </div>
                                </div>
                            </div>

                            <div className="p-4 bg-white border-t border-slate-100">
                                <div className="flex gap-2">
                                    <button className="p-3 text-slate-400 hover:bg-slate-100 rounded-xl transition-colors"><Plus size={20}/></button>
                                    <input 
                                        type="text" 
                                        placeholder={t.type}
                                        className="flex-grow bg-white border border-slate-200 rounded-xl px-4 outline-none focus:ring-2 focus:ring-blue-100 text-slate-900"
                                        value={newMessage}
                                        onChange={(e) => setNewMessage(e.target.value)}
                                    />
                                    <button className="p-3 bg-[#002060] text-white rounded-xl hover:bg-[#00308F] transition-colors shadow-lg">
                                        <Send size={18} />
                                    </button>
                                </div>
                            </div>
                        </>
                    ) : null}
                </div>
            </div>
        </div>
    );
};

export const ProfileView: React.FC<ViewProps & {userName?: string}> = ({userName, language}) => {
    const t = TRANSLATIONS[language].profile;
    return (
        <div className="max-w-6xl mx-auto px-6 py-12">
            <div className="bg-white rounded-3xl shadow-xl border border-slate-100 overflow-hidden">
                <div className="h-48 bg-gradient-to-r from-[#002060] to-[#004080]"></div>
                <div className="px-8 pb-8">
                    <div className="relative -mt-20 mb-6 flex justify-between items-end">
                        <div className="flex items-end gap-6">
                            <div className="w-40 h-40 rounded-full border-4 border-white shadow-lg overflow-hidden bg-white">
                                <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=400" className="w-full h-full object-cover" alt="Profile" />
                            </div>
                            <div className="mb-2">
                                <h1 className="text-3xl font-bold text-slate-900">{userName || 'Student Name'}</h1>
                                <p className="text-slate-500 font-medium flex items-center gap-2"><Award size={16} className="text-amber-500"/> Top 10% Student</p>
                            </div>
                        </div>
                        <button className="px-6 py-3 bg-white border border-slate-200 text-slate-700 font-bold rounded-xl hover:bg-slate-50 transition-colors shadow-sm">
                            {t.edit}
                        </button>
                    </div>

                    <div className="grid md:grid-cols-3 gap-8 mt-12">
                        <div className="space-y-6">
                            <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100">
                                <h3 className="font-bold text-slate-800 mb-4">{t.about}</h3>
                                <p className="text-slate-600 text-sm leading-relaxed">
                                    Passionate learner focused on Medical English and Clinical Research. Always looking to improve communication skills for international conferences.
                                </p>
                                <div className="mt-6 space-y-3">
                                    <div className="flex items-center gap-3 text-sm text-slate-600"><Mail size={16}/> student@asocim.org</div>
                                    <div className="flex items-center gap-3 text-sm text-slate-600"><Phone size={16}/> +52 55 1234 5678</div>
                                    <div className="flex items-center gap-3 text-sm text-slate-600"><Globe size={16}/> Mexico City</div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="md:col-span-2 grid grid-cols-2 gap-6">
                            <div className="p-6 bg-blue-50 rounded-2xl border border-blue-100">
                                <div className="text-4xl font-bold text-[#002060] mb-1">12</div>
                                <div className="text-sm font-bold text-blue-600 uppercase tracking-wide">{t.stats.courses}</div>
                            </div>
                            <div className="p-6 bg-emerald-50 rounded-2xl border border-emerald-100">
                                <div className="text-4xl font-bold text-emerald-700 mb-1">98%</div>
                                <div className="text-sm font-bold text-emerald-600 uppercase tracking-wide">{t.stats.grade}</div>
                            </div>
                            <div className="p-6 bg-purple-50 rounded-2xl border border-purple-100">
                                <div className="text-4xl font-bold text-purple-700 mb-1">156</div>
                                <div className="text-sm font-bold text-purple-600 uppercase tracking-wide">{t.stats.hours}</div>
                            </div>
                            <div className="p-6 bg-amber-50 rounded-2xl border border-amber-100">
                                <div className="text-4xl font-bold text-amber-700 mb-1">24</div>
                                <div className="text-sm font-bold text-amber-600 uppercase tracking-wide">{t.stats.badges}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export const HelpCenterView: React.FC<ViewProps> = ({ language }) => {
    const t = TRANSLATIONS[language].help;
    return (
        <div className="max-w-4xl mx-auto px-6 py-12 animate-fade-in-up">
            <div className="text-center mb-12">
                <h1 className="text-3xl font-bold text-[#002060] mb-4">{t.title}</h1>
                <div className="relative max-w-xl mx-auto">
                    <Search className="absolute left-4 top-4 text-slate-400" />
                    <input 
                        type="text" 
                        placeholder={t.search}
                        className="w-full pl-12 pr-4 py-4 rounded-2xl border border-slate-200 shadow-lg focus:ring-4 focus:ring-blue-50 outline-none bg-white text-slate-900"
                    />
                </div>
            </div>
            
            <div className="grid md:grid-cols-3 gap-6 mb-12">
                {t.categories.map((cat, i) => (
                    <button key={i} className="p-6 bg-white rounded-2xl shadow-sm border border-slate-100 hover:shadow-md hover:-translate-y-1 transition-all text-left group">
                        <h3 className="font-bold text-slate-800 group-hover:text-[#002060] mb-2">{cat}</h3>
                        <p className="text-sm text-slate-500">View 12 {t.articles}</p>
                    </button>
                ))}
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="p-6 border-b border-slate-50"><h3 className="font-bold text-lg">{t.faq}</h3></div>
                <div className="divide-y divide-slate-50">
                    {['How do I reset my password?', 'Where can I find my certificate?', 'How to contact my instructor?'].map((q, i) => (
                        <button key={i} className="w-full px-6 py-4 text-left hover:bg-slate-50 flex justify-between items-center group">
                            <span className="font-medium text-slate-700 group-hover:text-[#002060]">{q}</span>
                            <ChevronRight size={16} className="text-slate-300 group-hover:text-[#002060]"/>
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};

interface EditProfileViewProps extends ViewProps {
    userName?: string;
    onUpdateName?: (name: string) => void;
}

export const EditProfileView: React.FC<EditProfileViewProps> = ({ userName, onUpdateName, language }) => {
    const t = TRANSLATIONS[language].profile;
    const [formData, setFormData] = useState({
        firstName: userName ? userName.split(' ')[0] : 'Virtualizadora',
        lastName: userName && userName.split(' ').length > 1 ? userName.split(' ').slice(1).join(' ') : 'AC',
        email: 'student@asocim.org',
        bio: 'Passionate student focused on software development.',
        phone: '+52 55 1234 5678'
    });
    const [saving, setSaving] = useState(false);

    const handleSave = (e: React.FormEvent) => {
        e.preventDefault();
        setSaving(true);
        if(onUpdateName) onUpdateName(`${formData.firstName} ${formData.lastName}`);
        setTimeout(() => {
            setSaving(false);
            alert('Changes saved!');
        }, 1000);
    };

    return (
        <div className="max-w-4xl mx-auto px-4 py-12 animate-fade-in-up">
            <h2 className="text-3xl font-bold text-slate-800 mb-8">{t.edit}</h2>
            <div className="bg-white rounded-3xl shadow-lg border border-slate-100 overflow-hidden">
                <form onSubmit={handleSave} className="p-8 space-y-8">
                    <div className="flex items-center gap-6 pb-8 border-b border-slate-100">
                        <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-slate-50">
                            <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=300" alt="Profile" className="w-full h-full object-cover" />
                        </div>
                        <div>
                            <h3 className="font-bold text-slate-800">{t.form.photo}</h3>
                            <button type="button" className="text-blue-600 font-bold text-sm hover:underline">{t.form.change}</button>
                        </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">{t.form.first}</label>
                            <input 
                                type="text" 
                                value={formData.firstName} 
                                onChange={e => setFormData({...formData, firstName: e.target.value})}
                                className="w-full p-3 rounded-xl bg-white text-slate-900 border border-slate-200 focus:border-blue-500 outline-none transition-all" 
                            />
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">{t.form.last}</label>
                            <input 
                                type="text" 
                                value={formData.lastName} 
                                onChange={e => setFormData({...formData, lastName: e.target.value})}
                                className="w-full p-3 rounded-xl bg-white text-slate-900 border border-slate-200 focus:border-blue-500 outline-none transition-all" 
                            />
                        </div>
                        <div className="md:col-span-2">
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">{t.form.bio}</label>
                            <textarea 
                                value={formData.bio} 
                                onChange={e => setFormData({...formData, bio: e.target.value})}
                                rows={4}
                                className="w-full p-3 rounded-xl bg-white text-slate-900 border border-slate-200 focus:border-blue-500 outline-none transition-all" 
                            ></textarea>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-1.5">{t.form.email}</label>
                            <input 
                                type="email" 
                                value={formData.email} 
                                onChange={e => setFormData({...formData, email: e.target.value})}
                                className="w-full p-3 rounded-xl bg-white text-slate-900 border border-slate-200 focus:border-blue-500 outline-none transition-all" 
                            />
                        </div>
                    </div>

                    <div className="pt-4 flex justify-end gap-4">
                         <button type="submit" className="px-8 py-3 rounded-xl font-bold text-white bg-[#002060] hover:bg-[#00308F]">
                             {saving ? t.form.saving : t.form.save}
                         </button>
                    </div>
                </form>
            </div>
        </div>
    );
};
