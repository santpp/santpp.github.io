
import React, { useState, useEffect } from 'react';
import { 
    ShoppingCart, User, Home, LogOut, ArrowRight, Play, 
    Star, Award, Zap, Clock, Plus, TrendingUp, Target, 
    DollarSign, Check, Menu, X, CheckCircle, Search, Trash2,
    CreditCard, Lock, Calendar, AlertCircle, Pause, SkipForward, Volume2, Maximize,
    Globe, Briefcase, Heart, Smile, ChevronDown, Info
} from 'lucide-react';
import { ToastType } from '../components/ui/Toast';
import { Language } from '../types';
import { TRANSLATIONS } from '../constants';

interface LandingProps {
    onEnterApp: () => void;
    onShowToast: (message: string, type: ToastType) => void;
    initialTab?: string;
    language: Language;
    setLanguage: (lang: Language) => void;
}

const TutorialOverlay = ({ onClose, txt }: { onClose: () => void, txt: any }) => {
    return (
        <div className="fixed bottom-8 right-8 z-50 max-w-sm animate-fade-in-up">
            <div className="bg-white rounded-2xl shadow-2xl border border-[#002060]/10 overflow-hidden relative">
                <button onClick={onClose} className="absolute top-3 right-3 text-slate-400 hover:text-slate-600">
                    <X size={18} />
                </button>
                <div className="bg-[#002060] p-4 text-white">
                    <div className="flex items-center gap-2 mb-1">
                        <Info size={20} className="text-blue-300" />
                        <h3 className="font-bold">{txt.welcome}</h3>
                    </div>
                </div>
                <div className="p-5">
                    <p className="text-sm text-slate-600 mb-4 leading-relaxed">{txt.desc}</p>
                    <ul className="space-y-3 mb-6">
                        <li className="flex items-center gap-2 text-sm font-medium text-slate-800">
                            <CheckCircle size={16} className="text-green-500" /> {txt.step1}
                        </li>
                        <li className="flex items-center gap-2 text-sm font-medium text-slate-800">
                            <CheckCircle size={16} className="text-green-500" /> {txt.step2}
                        </li>
                        <li className="flex items-center gap-2 text-sm font-medium text-slate-800">
                            <CheckCircle size={16} className="text-green-500" /> {txt.step3}
                        </li>
                    </ul>
                    <button 
                        onClick={onClose}
                        className="w-full bg-[#002060] text-white py-2.5 rounded-xl font-bold text-sm hover:bg-[#00308F] transition-colors"
                    >
                        {txt.gotIt}
                    </button>
                </div>
            </div>
        </div>
    );
};

const QuickH5P = ({ onShowToast, language }: { onShowToast: (m: string, t: ToastType) => void, language: Language }) => {
    const [inputs, setInputs] = useState({ a: '', b: '' });
    const t = TRANSLATIONS[language].quickH5P;
    
    const check = () => {
        if (inputs.a.toLowerCase() === 'english' && inputs.b.toLowerCase() === 'job') {
            onShowToast(t.correct, 'success');
        } else {
            onShowToast(t.incorrect, 'error');
        }
    };

    return (
        <div className="py-20 bg-slate-50 text-center">
            <h2 className="text-3xl font-bold text-[#002060] mb-2">{t.title}</h2>
            <p className="text-slate-500 mb-10">{t.subtitle}</p>
            
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100 max-w-2xl mx-auto text-left">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">{t.instruction}</p>
                <div className="text-lg leading-loose font-medium text-slate-700">
                    "I am studying 
                    <input 
                        value={inputs.a} 
                        onChange={e => setInputs({...inputs, a: e.target.value})}
                        className="mx-2 px-3 py-1 bg-slate-100 border-b-2 border-slate-300 focus:border-[#002060] outline-none w-32 text-center font-bold text-[#002060] rounded-t"
                        placeholder="English" 
                    /> 
                    because I want a better 
                    <input 
                        value={inputs.b} 
                        onChange={e => setInputs({...inputs, b: e.target.value})}
                        className="mx-2 px-3 py-1 bg-slate-100 border-b-2 border-slate-300 focus:border-[#002060] outline-none w-24 text-center font-bold text-[#002060] rounded-t"
                        placeholder="job" 
                    />
                    ."
                </div>
                <button 
                    onClick={check}
                    className="mt-8 bg-[#000055] text-white px-6 py-3 rounded-lg font-bold text-sm hover:bg-[#000033] transition flex items-center gap-2"
                >
                    <CheckCircle size={18} /> {t.check}
                </button>
            </div>
        </div>
    );
};

const PaymentForm = ({ onCancel, onPay, language }: { onCancel: () => void, onPay: () => void, language: Language }) => {
    const [focus, setFocus] = useState<'front' | 'back'>('front');
    const [number, setNumber] = useState('');
    const [name, setName] = useState('');
    const [expiry, setExpiry] = useState('');
    const [cvc, setCvc] = useState('');
    const t = TRANSLATIONS[language].payment;

    return (
        <div className="animate-fade-in">
            {/* Card Visualizer */}
            <div className="w-full max-w-[320px] h-[200px] mx-auto mb-8 relative perspective-1000">
                <div className={`relative w-full h-full transition-transform duration-700 transform-style-3d ${focus === 'back' ? 'rotate-y-180' : ''}`}>
                    {/* Front */}
                    <div className="absolute inset-0 bg-gradient-to-br from-[#002060] to-[#004080] rounded-2xl p-6 text-white shadow-xl backface-hidden flex flex-col justify-between z-10">
                         <div className="flex justify-between items-center">
                             <div className="w-12 h-8 bg-yellow-500/80 rounded-md flex items-center justify-center">
                                 <div className="w-8 h-5 border border-white/30 rounded-sm"></div>
                             </div>
                             <span className="font-mono font-bold italic text-lg">VISA</span>
                         </div>
                         <div className="space-y-1">
                             <div className="font-mono text-xl tracking-widest shadow-black drop-shadow-md">
                                 {number || '•••• •••• •••• ••••'}
                             </div>
                         </div>
                         <div className="flex justify-between items-end">
                             <div>
                                 <p className="text-[10px] uppercase text-blue-200 opacity-80">{t.holder}</p>
                                 <p className="font-bold tracking-wide uppercase text-sm">{name || 'YOUR NAME'}</p>
                             </div>
                             <div>
                                 <p className="text-[10px] uppercase text-blue-200 opacity-80">{t.expiry}</p>
                                 <p className="font-bold tracking-wide text-sm">{expiry || 'MM/YY'}</p>
                             </div>
                         </div>
                    </div>
                    {/* Back */}
                    <div className="absolute inset-0 bg-gradient-to-br from-[#002570] to-[#003060] rounded-2xl shadow-xl backface-hidden rotate-y-180 flex flex-col py-6">
                        <div className="w-full h-10 bg-black mb-4"></div>
                        <div className="px-6">
                            <div className="bg-white h-10 flex items-center justify-end px-3 font-mono text-slate-900 font-bold">
                                {cvc || '•••'}
                            </div>
                            <p className="text-[10px] text-white mt-2 text-right">CVV/CVC code</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Form */}
            <div className="space-y-4">
                <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">{t.cardNo}</label>
                    <div className="relative">
                        <CreditCard className="absolute left-3 top-3 text-slate-400" size={20} />
                        <input 
                            type="text" 
                            maxLength={19}
                            placeholder="0000 0000 0000 0000" 
                            className="w-full pl-10 p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-[#002060] transition-all"
                            value={number}
                            onChange={e => setNumber(e.target.value)}
                            onFocus={() => setFocus('front')}
                        />
                    </div>
                </div>
                <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase mb-1">{t.holder}</label>
                    <input 
                        type="text" 
                        placeholder="JOHN DOE" 
                        className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-[#002060] transition-all"
                        value={name}
                        onChange={e => setName(e.target.value)}
                        onFocus={() => setFocus('front')}
                    />
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">{t.expiry}</label>
                        <input 
                            type="text" 
                            placeholder="MM/YY" 
                            maxLength={5}
                            className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-[#002060] transition-all"
                            value={expiry}
                            onChange={e => setExpiry(e.target.value)}
                            onFocus={() => setFocus('front')}
                        />
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase mb-1">{t.cvc}</label>
                        <input 
                            type="text" 
                            placeholder="123" 
                            maxLength={3}
                            className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:border-[#002060] transition-all"
                            value={cvc}
                            onChange={e => setCvc(e.target.value)}
                            onFocus={() => setFocus('back')}
                        />
                    </div>
                </div>
                
                <div className="flex gap-4 pt-4">
                    <button onClick={onCancel} className="w-1/2 py-3 border border-slate-200 text-slate-600 font-bold rounded-xl hover:bg-slate-50">{TRANSLATIONS[language].common.cancel}</button>
                    <button onClick={onPay} className="w-1/2 py-3 bg-[#002060] text-white font-bold rounded-xl hover:bg-[#00308F] shadow-lg">{t.pay}</button>
                </div>
            </div>
        </div>
    );
};

export const H5PInteractiveVideo = () => {
    const [isPlaying, setIsPlaying] = useState(false);
    const [showInteraction, setShowInteraction] = useState(false);
    const [progress, setProgress] = useState(35);

    return (
        <div className="bg-black rounded-xl overflow-hidden shadow-2xl relative group aspect-video">
            <img 
                src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=1000&auto=format&fit=crop" 
                className="absolute inset-0 w-full h-full object-cover opacity-60 grayscale hover:grayscale-0 transition-all duration-500"
                alt="Video Content"
            />
            
            <div className={`absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 transition-all duration-500 ${showInteraction ? 'scale-100 opacity-100' : 'scale-95 opacity-0 pointer-events-none'}`}>
                <div className="bg-white p-6 rounded-2xl shadow-2xl max-w-sm w-full animate-scale-in border-2 border-[#000055]">
                    <div className="flex justify-between items-center mb-4">
                        <span className="text-xs font-bold bg-blue-100 text-blue-600 px-2 py-1 rounded uppercase">Multiple Choice</span>
                        <span className="text-xs text-slate-400">00:45</span>
                    </div>
                    <h4 className="font-bold text-slate-800 mb-4 text-lg">What implies the term "Active Listening"?</h4>
                    <div className="space-y-2">
                        <button className="w-full text-left p-3 rounded-lg border border-slate-200 hover:bg-blue-50 hover:border-blue-500 transition-colors text-sm font-medium bg-white">A. Listening while doing other tasks</button>
                        <button className="w-full text-left p-3 rounded-lg border border-slate-200 hover:bg-blue-50 hover:border-blue-500 transition-colors text-sm font-medium bg-white">B. Fully concentrating on what is being said</button>
                        <button className="w-full text-left p-3 rounded-lg border border-slate-200 hover:bg-blue-50 hover:border-blue-500 transition-colors text-sm font-medium bg-white">C. Listening only to reply</button>
                    </div>
                    <button onClick={() => setShowInteraction(false)} className="mt-4 w-full bg-[#000055] text-white py-2 rounded-lg font-bold text-sm hover:bg-[#00308F]">Submit Answer</button>
                </div>
            </div>

            {!showInteraction && (
                 <button 
                    onClick={() => setShowInteraction(true)}
                    className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center group-hover:scale-110 transition-transform cursor-pointer border-2 border-white"
                 >
                    <div className="w-12 h-12 bg-[#000055] rounded-full flex items-center justify-center shadow-lg">
                        <Play size={24} fill="white" className="text-white ml-1" />
                    </div>
                 </button>
            )}

            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 to-transparent p-4 pt-12 opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="h-1.5 bg-white/30 rounded-full mb-4 cursor-pointer relative group/timeline">
                    <div className="absolute inset-y-0 left-0 bg-[#000055] rounded-full" style={{ width: `${progress}%` }}></div>
                    <div className="absolute top-1/2 -translate-y-1/2 left-[35%] w-3 h-3 bg-white rounded-full border-2 border-[#000055] cursor-pointer hover:scale-125 transition-transform"></div>
                </div>
                <div className="flex justify-between items-center text-white">
                    <div className="flex items-center gap-4">
                        <button onClick={() => setIsPlaying(!isPlaying)}>
                             {isPlaying ? <Pause size={20} /> : <Play size={20} fill="white" />}
                        </button>
                        <span className="text-xs font-medium">00:45 / 02:30</span>
                    </div>
                    <div className="flex items-center gap-4">
                        <Volume2 size={20} />
                        <Maximize size={20} />
                    </div>
                </div>
            </div>
        </div>
    );
};

const Logo = ({ onClick }: { onClick: () => void }) => (
    <div onClick={onClick} className="flex items-center cursor-pointer select-none gap-0.5 group shrink-0">
        <span className="text-2xl md:text-3xl font-extrabold text-[#000055] font-display tracking-tight">ASOCIM</span>
        <div className="bg-[#000055] text-white px-1 ml-0.5 pt-0.5 pb-0 rounded-sm">
            <span className="text-lg md:text-xl font-bold font-display">PLUS</span>
        </div>
    </div>
);

export const Landing: React.FC<LandingProps> = ({ onEnterApp, onShowToast, initialTab, language, setLanguage }) => {
    const [tab, setTab] = useState(initialTab || 'Inicio');
    const [showTutorial, setShowTutorial] = useState(true);
    const [menuOpen, setMenuOpen] = useState(false);
    const [cart, setCart] = useState<{name: string, price: number}[]>([]);
    const [modal, setModal] = useState<'cart' | 'checkout' | 'success' | null>(null);

    const txt = TRANSLATIONS[language];
    const navTxt = txt.nav;

    // Logos
    const PARTNER_LOGOS = [
        { n: "Microsoft", u: "https://upload.wikimedia.org/wikipedia/commons/9/96/Microsoft_logo_%282012%29.svg" },
        { n: "Spotify", u: "https://storage.googleapis.com/pr-newsroom-wp/1/2018/11/Spotify_Logo_RGB_White.png" },
        { n: "Amazon", u: "https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg" },
        { n: "Uber", u: "https://upload.wikimedia.org/wikipedia/commons/c/cc/Uber_logo_2018.png" },
        { n: "Google", u: "https://upload.wikimedia.org/wikipedia/commons/2/2f/Google_2015_logo.svg" }
    ];

    useEffect(() => {
        if (initialTab) setTab(initialTab);
    }, [initialTab]);

    const addToCart = (item: string, price: number) => {
        setCart([...cart, {name: item, price}]);
        setModal('cart');
    };

    const removeFromCart = (index: number) => {
        const newCart = [...cart];
        newCart.splice(index, 1);
        setCart(newCart);
    };

    const cartTotal = cart.reduce((sum, item) => sum + item.price, 0);

    const tabMapping: { [key: string]: string } = {
        'Inicio': navTxt.home,
        'Cursos': navTxt.courses,
        'Tienda': navTxt.store,
        'Aula': navTxt.classroom,
        'Precios': navTxt.pricing,
        'Empresa': navTxt.corporate,
        'Sobre nosotros': navTxt.about
    };
    const tabs = Object.values(tabMapping);

    const handleTabClick = (label: string) => {
        const internalKey = Object.keys(tabMapping).find(key => tabMapping[key] === label) || 'Inicio';
        if (internalKey === 'Aula') onEnterApp();
        else {
            setTab(internalKey);
            setMenuOpen(false);
        }
    };

    return (
        <div className="min-h-screen flex flex-col font-sans bg-white selection:bg-[#000055] selection:text-white relative">
            {showTutorial && <TutorialOverlay onClose={() => setShowTutorial(false)} txt={txt.landing.tutorial} />}

            {/* Header */}
            <nav className="sticky top-0 z-[60] bg-white/95 backdrop-blur shadow-sm py-2 border-b border-slate-100">
                <div className="max-w-[1600px] w-full mx-auto px-6 flex justify-between items-center">
                    <Logo onClick={() => setTab('Inicio')} />
                    
                    <div className="hidden lg:flex items-center gap-8 flex-1 justify-center">
                        {tabs.map(t => (
                            <button 
                                key={t} 
                                onClick={() => handleTabClick(t)} 
                                className={`text-[15px] font-medium transition relative px-1 ${tabMapping[tab]===t ? 'text-[#000055] font-bold' : 'text-slate-600 hover:text-[#000055]'}`}
                            >
                                {t}
                                {tabMapping[tab]===t && <span className="absolute -bottom-2 left-0 w-full h-[3px] bg-[#000055] rounded-full"></span>}
                            </button>
                        ))}
                    </div>

                    <div className="flex items-center gap-6">
                        <div className="relative group">
                             <button className="flex items-center gap-1 text-[#000055] font-bold text-sm">
                                 <Globe size={18} /> <span>{language}</span> <ChevronDown size={14} />
                             </button>
                             <div className="absolute right-0 top-full pt-2 hidden group-hover:block">
                                <div className="bg-white shadow-lg rounded-xl border border-slate-100 p-2 flex flex-col gap-1">
                                    {(['EN', 'ES', 'FR'] as Language[]).map(lang => (
                                        <button key={lang} onClick={() => setLanguage(lang)} className="px-4 py-2 hover:bg-slate-50 text-left rounded-lg text-sm font-bold text-[#000055]">{lang}</button>
                                    ))}
                                </div>
                             </div>
                        </div>
                        <button onClick={() => setModal('cart')} className="relative text-[#000055] hover:scale-110 transition-transform">
                            <ShoppingCart size={22} />
                            {cart.length > 0 && (
                                <span className="absolute -top-2 -right-2 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center text-xs font-bold shadow-sm">{cart.length}</span>
                            )}
                        </button>
                        <button onClick={() => onEnterApp()} className="hidden md:flex items-center gap-3 hover:opacity-80">
                            <span className="text-sm font-bold text-[#000055]">My Account</span>
                            <div className="w-10 h-10 rounded-full bg-[#000055] text-white flex items-center justify-center font-bold border-2 border-blue-100">
                                <User size={20} />
                            </div>
                        </button>
                         <button onClick={() => setMenuOpen(true)} className="lg:hidden text-[#000055]"><Menu size={28} /></button>
                    </div>
                </div>
            </nav>

            {/* Mobile Menu */}
            {menuOpen && (
                <div className="fixed inset-0 z-[100] bg-white p-6 flex flex-col animate-fade-in">
                    <div className="flex justify-between mb-8">
                        <Logo onClick={() => setMenuOpen(false)} />
                        <button onClick={() => setMenuOpen(false)}><X size={28} /></button>
                    </div>
                    {tabs.map(t => (
                        <button key={t} onClick={() => handleTabClick(t)} className="text-left p-4 border-b border-slate-100 font-bold text-[#000055] text-lg">
                            {t}
                        </button>
                    ))}
                </div>
            )}

            <main className="flex-grow">
                {tab === 'Inicio' && (
                     <div className="animate-fade-in">
                        <section className="relative pt-12 pb-24 lg:pt-20 lg:pb-32 overflow-hidden">
                             <div className="max-w-[1400px] mx-auto px-6 grid lg:grid-cols-2 gap-12 items-center">
                                 <div className="order-2 lg:order-1">
                                     <div className="inline-flex items-center gap-2 bg-white border border-slate-200 rounded-full px-4 py-1.5 mb-8 shadow-sm">
                                         <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                                         <span className="text-xs font-bold text-slate-600 uppercase tracking-wide">{txt.landing.newSpots}</span>
                                     </div>
                                     
                                     <h1 className="text-6xl lg:text-7xl font-extrabold text-[#000055] mb-6 leading-[1.1] tracking-tight">
                                         {txt.landing.heroTitleLine1} <br/> {txt.landing.heroTitleLine2} <br/>
                                         <span className="text-[#2563EB]">{txt.landing.heroTitleSpan}</span>
                                     </h1>
                                     
                                     <p className="text-xl text-slate-500 mb-10 max-w-lg leading-relaxed font-medium">
                                         {txt.landing.heroSubtitle}
                                     </p>
                                     
                                     <div className="flex flex-col sm:flex-row gap-4 mb-12">
                                         <button onClick={() => setTab('Cursos')} className="bg-[#000055] text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-[#000033] transition shadow-lg shadow-blue-900/20 flex items-center justify-center gap-2">
                                             {txt.landing.ctaStart} <ArrowRight size={20} />
                                         </button>
                                         <button className="bg-white border-2 border-slate-100 text-[#000055] px-8 py-4 rounded-xl font-bold text-lg hover:bg-slate-50 transition flex items-center justify-center gap-3">
                                             <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center text-red-600"><Play size={14} fill="currentColor" /></div>
                                             {txt.landing.ctaDemo}
                                         </button>
                                     </div>

                                     <div className="flex items-center gap-4">
                                         <div className="flex -space-x-3">
                                             {[1,2,3,4].map((i) => (
                                                 <img key={i} className="w-10 h-10 rounded-full border-2 border-white object-cover" src={`https://images.unsplash.com/photo-${i===1?'1534528741775-53994a69daeb':i===2?'1506794778202-cad84cf45f1d':i===3?'1507003211169-0a1dd7228f2d':'1500648767791-00dcc994a43e'}?w=64&h=64&fit=crop`} alt="Student"/>
                                             ))}
                                         </div>
                                         <div className="text-sm">
                                             <div className="flex text-yellow-400 text-xs mb-0.5"><Star className="fill-current" size={12}/><Star className="fill-current" size={12}/><Star className="fill-current" size={12}/><Star className="fill-current" size={12}/><Star className="fill-current" size={12}/></div>
                                             <span className="text-slate-500 font-medium">Unete a <strong className="text-[#000055]">+50,000 {txt.landing.students}</strong></span>
                                         </div>
                                     </div>
                                 </div>

                                 <div className="relative order-1 lg:order-2 flex justify-center lg:justify-end">
                                     <div className="relative w-full max-w-[500px] animate-float">
                                         <div className="bg-white p-4 rounded-[2.5rem] shadow-2xl border border-slate-100">
                                             <div className="relative rounded-[2rem] overflow-hidden aspect-square group">
                                                 <img 
                                                     src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=1000&auto=format&fit=crop" 
                                                     className="w-full h-full object-cover grayscale hover:grayscale-0 transition duration-700 group-hover:scale-105"
                                                     alt="Live Class"
                                                 />
                                                 
                                                 <div className="absolute top-8 left-8 bg-white/95 backdrop-blur-sm p-3 rounded-2xl flex items-center gap-3 shadow-lg animate-scale-in">
                                                     <div className="bg-green-100 text-green-600 p-2 rounded-xl">
                                                         <Award size={24} strokeWidth={3} />
                                                     </div>
                                                     <div className="leading-tight pr-2">
                                                         <p className="text-sm font-bold text-[#002060]">Level B2</p>
                                                         <p className="text-[10px] text-slate-500 font-medium">Completed</p>
                                                     </div>
                                                 </div>

                                                 <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent p-8 pt-24 text-white">
                                                     <h3 className="text-3xl font-bold mb-1">Live Class</h3>
                                                     <div className="flex justify-between items-end">
                                                         <p className="text-sm text-slate-200 font-medium">Prof. Sarah Jenkins • London</p>
                                                         <span className="bg-[#dc3545] text-white text-[10px] font-bold px-2 py-1 rounded uppercase tracking-wider shadow-sm animate-pulse">LIVE</span>
                                                     </div>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                        </section>

                        {/* PARTNER LOGOS STRIP */}
                        <section className="py-12 bg-[#000044] overflow-hidden">
                            <div className="flex whitespace-nowrap animate-scroll gap-24 items-center px-10">
                                {[...PARTNER_LOGOS, ...PARTNER_LOGOS, ...PARTNER_LOGOS].map((l,i) => (
                                    <img key={i} src={l.u} className="h-8 w-auto logo-filter brightness-0 invert opacity-60 hover:opacity-100 transition-opacity" alt={l.n} />
                                ))}
                            </div>
                        </section>

                        <QuickH5P onShowToast={onShowToast} language={language} />

                        {/* H5P VIDEO SECTION */}
                        <div className="max-w-[1400px] mx-auto px-6 py-24">
                            <div className="text-center mb-12">
                                <h3 className="text-3xl font-bold text-[#000055] mb-4">{txt.landing.interactiveTitle}</h3>
                                <p className="text-slate-500 max-w-2xl mx-auto">{txt.landing.interactiveSubtitle}</p>
                            </div>
                            <H5PInteractiveVideo />
                        </div>
                     </div>
                )}

                {tab === 'Tienda' && (
                    <div className="max-w-[1400px] mx-auto px-6 py-12 animate-fade-in">
                        <div className="flex flex-col md:flex-row justify-between items-end mb-12 border-b border-slate-100 pb-8 gap-4">
                            <div>
                                <h2 className="text-4xl font-display font-bold text-[#000055] mb-2">{txt.store.title}</h2>
                                <p className="text-slate-500">{txt.store.subtitle}</p>
                            </div>
                            <div className="bg-blue-50 text-blue-600 px-4 py-2 rounded-lg font-bold text-sm flex items-center gap-2">
                                <Star className="fill-current" size={16} /> 1,250 {txt.common.points}
                            </div>
                        </div>
                        
                        <div className="grid md:grid-cols-4 gap-8">
                            {[
                                {t: txt.store.items.s1, p: 25, tag: txt.store.tags.shipping, img: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=600"},
                                {t: txt.store.items.s2, p: 45, tag: txt.store.tags.merch, img: "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=600"},
                                {t: txt.store.items.s3, p: 15, tag: txt.store.tags.digital, img: "https://images.unsplash.com/photo-1610453819409-528044006681?w=600"},
                                {t: txt.store.items.s4, p: 50, tag: txt.store.tags.live, img: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=600"},
                                {t: txt.store.items.s5, p: 12, tag: txt.store.tags.app, img: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=600"},
                                {t: txt.store.items.s6, p: 18, tag: txt.store.tags.paper, img: "https://images.unsplash.com/photo-1531346878377-a51e1959de39?w=600"},
                                {t: txt.store.items.s7, p: 60, tag: txt.store.tags.tech, img: "https://images.unsplash.com/photo-1593642532400-2682810df593?w=600"},
                                {t: txt.store.items.s8, p: 20, tag: txt.store.tags.official, img: "https://images.unsplash.com/photo-1589829085413-56de8ae18c73?w=600"},
                            ].map((item, i) => (
                                <div key={i} className="bg-white rounded-2xl border border-slate-100 overflow-hidden group hover:shadow-xl transition duration-300 flex flex-col">
                                    <div className="h-48 overflow-hidden relative bg-slate-50">
                                        <img src={item.img} className="w-full h-full object-cover group-hover:scale-105 transition duration-700" alt={item.t}/>
                                        <span className="absolute top-3 right-3 bg-white/90 backdrop-blur px-2 py-1 rounded text-xs font-bold text-[#000055] uppercase shadow-sm">{item.tag}</span>
                                    </div>
                                    <div className="p-5 flex-grow flex flex-col">
                                        <h3 className="font-bold text-[#000055] mb-1">{item.t}</h3>
                                        <div className="mt-auto flex justify-between items-center pt-4 border-t border-slate-50">
                                            <span className="text-2xl font-bold text-[#000055]">${item.p}</span>
                                            <button onClick={() => addToCart(item.t, item.p)} className="w-8 h-8 bg-blue-50 rounded-full text-[#000055] hover:bg-[#000055] hover:text-white flex items-center justify-center transition">
                                                <Plus size={18} />
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {tab === 'Cursos' && (
                    <div className="animate-fade-in bg-slate-50 min-h-screen py-12">
                        <div className="max-w-[1400px] mx-auto px-6">
                            <div className="flex items-center justify-between mb-8">
                                <div>
                                    <h3 className="text-2xl font-bold text-[#000055]">{txt.courses.title}</h3>
                                    <p className="text-slate-500">{txt.courses.subtitle}</p>
                                </div>
                                <div className="flex gap-2">
                                    <button className="bg-white border px-4 py-2 rounded-lg text-sm font-bold hover:bg-gray-50">{txt.courses.levels.basic}</button>
                                    <button className="bg-white border px-4 py-2 rounded-lg text-sm font-bold hover:bg-gray-50">{txt.courses.levels.advanced}</button>
                                    <button className="bg-white border px-4 py-2 rounded-lg text-sm font-bold hover:bg-gray-50">{txt.courses.levels.specific}</button>
                                </div>
                            </div>

                            <div className="grid md:grid-cols-3 gap-8">
                                {[
                                    {t: txt.courses.items.c1, p: 199, l: txt.courses.levels.basic}, 
                                    {t: txt.courses.items.c2, p: 149, l: txt.courses.levels.advanced}, 
                                    {t: txt.courses.items.c3, p: 129, l: txt.courses.levels.exam}, 
                                    {t: txt.courses.items.c4, p: 159, l: txt.courses.levels.specific}, 
                                    {t: txt.courses.items.c5, p: 99, l: txt.courses.levels.intermediate}, 
                                    {t: txt.courses.items.c6, p: 89, l: txt.courses.levels.all}
                                ].map((c, i) => (
                                    <div key={i} className="bg-white rounded-2xl shadow-sm hover:shadow-xl transition duration-300 border border-slate-100 flex flex-col group overflow-hidden">
                                        <div className="h-48 overflow-hidden relative bg-slate-100">
                                            <img src={`https://images.unsplash.com/photo-${i % 2 === 0 ? '1523240795612-9a054b0db644' : '1513258496098-dad81dcc0c27'}?w=600&q=80`} className="w-full h-full object-cover group-hover:scale-110 transition duration-700" alt={c.t}/>
                                            <span className="absolute top-3 right-3 bg-white text-[#000055] text-[10px] font-bold px-2 py-1 rounded uppercase shadow">{c.l}</span>
                                        </div>
                                        <div className="p-6 flex-grow">
                                            <h4 className="text-xl font-bold text-[#000055] mb-2 group-hover:text-blue-600">{c.t}</h4>
                                            <p className="text-sm text-slate-500 mb-4">{txt.courses.desc}</p>
                                            <div className="flex items-center gap-1 text-yellow-400 text-xs mb-4">
                                                <Star className="fill-current" size={12}/><Star className="fill-current" size={12}/><Star className="fill-current" size={12}/><Star className="fill-current" size={12}/><Star className="fill-current" size={12}/> (4.9)
                                            </div>
                                            <button onClick={() => addToCart(c.t, c.p)} className="w-full border border-[#000055] text-[#000055] py-2 rounded-lg font-bold hover:bg-[#000055] hover:text-white transition">
                                                {txt.common.addToCart} - ${c.p}
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                )}

                {tab === 'Precios' && (
                    <div className="bg-slate-50 py-24 animate-fade-in">
                        <div className="max-w-[1200px] mx-auto px-6">
                            <div className="text-center mb-16">
                                <h1 className="text-4xl font-bold text-[#000055] mb-4">{txt.pricing.title}</h1>
                                <p className="text-slate-500">{txt.pricing.subtitle}</p>
                            </div>
                            <div className="grid md:grid-cols-3 gap-8">
                                {[
                                    { plan: txt.pricing.monthly, highlight: false },
                                    { plan: txt.pricing.semester, highlight: true },
                                    { plan: txt.pricing.vip, highlight: false }
                                ].map((item, idx) => (
                                    <div key={idx} className={`p-8 rounded-3xl border transition relative ${item.highlight ? 'bg-[#002060] text-white shadow-2xl scale-105 border-white/20' : 'bg-white border-slate-200 hover:shadow-xl'}`}>
                                        {item.highlight && (
                                            <div className="absolute top-0 right-0 bg-yellow-400 text-[#000055] px-3 py-1 rounded-bl-xl rounded-tr-2xl font-bold text-xs uppercase">{txt.common.popular}</div>
                                        )}
                                        <h3 className={`text-xl font-bold ${item.highlight ? 'text-white' : 'text-slate-600'}`}>{item.plan.title}</h3>
                                        <div className={`text-4xl font-bold my-4 ${item.highlight ? 'text-white' : 'text-[#000055]'}`}>${item.plan.price}</div>
                                        <ul className="space-y-3 mb-8">
                                            {item.plan.features.map((f: string, i: number) => (
                                                <li key={i} className="flex items-center gap-3 text-sm font-medium opacity-80">
                                                    <CheckCircle size={16} className={item.highlight ? 'text-green-400' : 'text-green-600'} /> {f}
                                                </li>
                                            ))}
                                        </ul>
                                        <button 
                                            onClick={() => addToCart(item.plan.title, parseInt(item.plan.price))}
                                            className={`w-full py-3 rounded-xl font-bold transition ${item.highlight ? 'bg-white text-[#000055] hover:bg-gray-100' : 'border-2 border-[#000055] text-[#000055] hover:bg-[#000055] hover:text-white'}`}
                                        >
                                            {txt.common.select}
                                        </button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                )}

                {tab === 'Empresa' && (
                    <div className="animate-fade-in">
                        <div className="bg-[#000033] text-white py-24 text-center">
                            <h1 className="text-5xl font-bold mb-8">{txt.corporate.title}</h1>
                            <p className="text-xl text-slate-300 mb-10">{txt.corporate.subtitle}</p>
                            <button className="bg-white text-[#000033] px-8 py-3 rounded-xl font-bold hover:bg-blue-50">{txt.corporate.schedule}</button>
                        </div>
                        <div className="max-w-[1200px] mx-auto px-6 py-24 grid md:grid-cols-3 gap-8 -mt-32 relative z-10">
                            <div className="bg-white p-8 rounded-2xl shadow-xl">
                                <TrendingUp size={40} className="text-blue-600 mb-4"/>
                                <h3 className="text-xl font-bold text-[#000055] mb-2">{txt.corporate.feature1}</h3>
                                <p className="text-slate-600">{txt.corporate.feature1Desc}</p>
                            </div>
                            <div className="bg-white p-8 rounded-2xl shadow-xl">
                                <Target size={40} className="text-green-600 mb-4"/>
                                <h3 className="text-xl font-bold text-[#000055] mb-2">{txt.corporate.feature2}</h3>
                                <p className="text-slate-600">{txt.corporate.feature2Desc}</p>
                            </div>
                            <div className="bg-white p-8 rounded-2xl shadow-xl">
                                <DollarSign size={40} className="text-purple-600 mb-4"/>
                                <h3 className="text-xl font-bold text-[#000055] mb-2">{txt.corporate.feature3}</h3>
                                <p className="text-slate-600">{txt.corporate.feature3Desc}</p>
                            </div>
                        </div>
                    </div>
                )}

                {tab === 'Sobre nosotros' && (
                    <div className="animate-fade-in py-24 text-center">
                         <h1 className="text-5xl font-bold text-[#000055] mb-6">{txt.about.title}</h1>
                         <p className="text-2xl text-slate-500 max-w-3xl mx-auto font-light">"{txt.about.mission}"</p>
                         <div className="max-w-[1200px] mx-auto px-6 grid md:grid-cols-2 gap-16 items-center mt-24">
                             <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800" className="rounded-3xl shadow-2xl rotate-2" alt="Team"/>
                             <div className="text-left">
                                 <h2 className="text-3xl font-bold text-[#000055] mb-6">{txt.about.storyTitle}</h2>
                                 <p className="text-slate-600 leading-relaxed">{txt.about.story}</p>
                             </div>
                         </div>
                    </div>
                )}
            </main>

            {/* Footer with White Background Logo */}
            <footer className="bg-[#000055] text-slate-300 py-16 border-t border-white/10">
                <div className="max-w-[1400px] mx-auto px-6 grid md:grid-cols-4 gap-12 text-sm">
                    <div>
                        <div className="bg-white p-3 rounded-xl inline-block mb-4 shadow-lg">
                             <Logo onClick={() => {}} />
                        </div>
                        <p className="mt-2 opacity-80">{txt.footer.desc}</p>
                    </div>
                    <div>
                        <h4 className="text-white font-bold mb-6 text-base">{txt.footer.nav}</h4>
                        <ul className="space-y-3">
                            <li><button onClick={()=>handleTabClick('Inicio')} className="hover:text-white">{txt.nav.home}</button></li>
                            <li><button onClick={()=>handleTabClick('Cursos')} className="hover:text-white">{txt.nav.courses}</button></li>
                            <li><button onClick={()=>handleTabClick('Precios')} className="hover:text-white">{txt.nav.pricing}</button></li>
                            <li><button onClick={()=>handleTabClick('Tienda')} className="hover:text-white">{txt.nav.store}</button></li>
                        </ul>
                    </div>
                    <div>
                        <h4 className="text-white font-bold mb-6 text-base">{txt.footer.support}</h4>
                        <ul className="space-y-3">
                            <li><a href="#" className="hover:text-white">{txt.help.title}</a></li>
                            <li><a href="#" className="hover:text-white">Contact</a></li>
                            <li><a href="#" className="hover:text-white">Terms</a></li>
                            <li><a href="#" className="hover:text-white">Privacy</a></li>
                        </ul>
                    </div>
                    <div>
                        <h4 className="text-white font-bold mb-6 text-base">{txt.footer.newsletter}</h4>
                        <p className="text-xs mb-4 opacity-70">{txt.footer.newsDesc}</p>
                        <div className="flex">
                            <input className="bg-[#000055] border border-slate-600 p-3 rounded-l-lg text-white w-full outline-none focus:border-white" placeholder="Email"/>
                            <button className="bg-white text-[#000055] px-4 font-bold rounded-r-lg">{txt.footer.go}</button>
                        </div>
                    </div>
                </div>
                <div className="max-w-[1400px] mx-auto px-6 mt-12 pt-8 border-t border-white/10 text-center text-xs opacity-50">
                    &copy; 2025 ASOCIM Plus Inc. All rights reserved.
                </div>
            </footer>

            {/* --- MODALS --- */}
            
            {/* Cart/Checkout Modal */}
            {modal && (
                <div className="fixed inset-0 z-[200] flex items-center justify-center bg-[#000055]/50 backdrop-blur-sm p-4" onClick={() => setModal(null)}>
                    <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl animate-scale-in overflow-hidden" onClick={e => e.stopPropagation()}>
                        
                        {modal === 'cart' && (
                            <div className="p-8">
                                <div className="flex justify-between items-center mb-6">
                                    <h2 className="text-2xl font-bold text-[#000055] flex items-center gap-2">
                                        <ShoppingCart className="text-blue-600"/> Your Cart
                                    </h2>
                                    <button onClick={() => setModal(null)} className="text-slate-400 hover:text-slate-600"><X size={24}/></button>
                                </div>
                                {cart.length > 0 ? (
                                    <>
                                        <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2 mb-6">
                                            {cart.map((c, i) => (
                                                <div key={i} className="flex justify-between items-center p-3 bg-slate-50 rounded-xl border border-slate-100">
                                                    <div>
                                                        <p className="font-bold text-slate-800 text-sm">{c.name}</p>
                                                        <p className="text-xs text-slate-500">Item #{i+1024}</p>
                                                    </div>
                                                    <div className="flex items-center gap-4">
                                                        <span className="font-bold text-[#000055]">${c.price}</span>
                                                        <button onClick={() => removeFromCart(i)} className="text-red-400 hover:text-red-600"><Trash2 size={16}/></button>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                        <div className="flex justify-between py-4 border-t border-slate-100 mb-6">
                                            <span className="text-slate-500 font-medium">Total</span>
                                            <span className="text-2xl font-bold text-[#000055]">${cartTotal}</span>
                                        </div>
                                        <button 
                                            onClick={() => setModal('checkout')}
                                            className="w-full bg-[#002060] text-white py-4 rounded-xl font-bold shadow-lg hover:bg-[#00308F] transition flex items-center justify-center gap-2"
                                        >
                                            Proceed to Checkout <ArrowRight size={18}/>
                                        </button>
                                    </>
                                ) : (
                                    <div className="text-center py-12">
                                        <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-400">
                                            <ShoppingCart size={32}/>
                                        </div>
                                        <p className="text-slate-500">Your cart is empty.</p>
                                        <button onClick={() => setModal(null)} className="mt-6 text-[#002060] font-bold hover:underline">Continue Shopping</button>
                                    </div>
                                )}
                            </div>
                        )}

                        {modal === 'checkout' && (
                            <div className="p-8">
                                <div className="flex justify-between items-center mb-6">
                                    <h2 className="text-xl font-bold text-[#000055]">{txt.payment.pay}</h2>
                                    <div className="flex gap-2">
                                        <div className="w-8 h-5 bg-slate-100 rounded border border-slate-200"></div>
                                        <div className="w-8 h-5 bg-slate-100 rounded border border-slate-200"></div>
                                    </div>
                                </div>
                                <PaymentForm 
                                    onCancel={() => setModal('cart')} 
                                    onPay={() => {
                                        setTimeout(() => {
                                            setCart([]);
                                            setModal('success');
                                        }, 1500);
                                    }} 
                                    language={language}
                                />
                            </div>
                        )}

                        {modal === 'success' && (
                            <div className="p-12 text-center">
                                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6 text-green-600 animate-scale-in">
                                    <CheckCircle size={40} className="fill-current text-white"/>
                                </div>
                                <h2 className="text-2xl font-bold text-[#000055] mb-2">{txt.payment.success}</h2>
                                <p className="text-slate-500 mb-8 text-sm">{txt.payment.processed}</p>
                                <button onClick={() => setModal(null)} className="bg-[#000055] text-white px-8 py-3 rounded-xl font-bold w-full hover:bg-[#00308F]">{txt.payment.continue}</button>
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
};