
import React, { useState } from 'react';
import { Eye, EyeOff, User, Lock, ArrowRight, ChevronLeft } from 'lucide-react';
import { ToastType } from '../components/ui/Toast';
import { Language } from '../types';
import { TRANSLATIONS } from '../constants';

interface LoginProps {
  onLogin: (username?: string) => void;
  onShowToast: (message: string, type: ToastType) => void;
  onBack: () => void;
  language: Language;
}

export const Login: React.FC<LoginProps> = ({ onLogin, onShowToast, onBack, language }) => {
  const [showPassword, setShowPassword] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const t = TRANSLATIONS[language].login;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
        setIsLoading(false);
        onLogin(username || 'Virtualizadora AC');
    }, 1500);
  };

  return (
    <div className="min-h-screen w-full flex relative overflow-hidden bg-[#0f172a]">
        {/* Cinematic Background */}
        <div className="absolute inset-0 z-0">
            <img 
                src="https://images.unsplash.com/photo-1497864149936-d7b610153147?q=80&w=2070&auto=format&fit=crop" 
                className="w-full h-full object-cover opacity-40 animate-breathe"
                alt="Background" 
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#002060]/90 to-[#0f172a]/80 backdrop-blur-[2px]"></div>
        </div>

        {/* Back Button */}
        <button 
            onClick={onBack}
            className="absolute top-8 left-8 z-50 flex items-center gap-2 text-white/80 hover:text-white bg-white/10 hover:bg-white/20 px-4 py-2 rounded-full backdrop-blur transition-all border border-white/10 group"
        >
            <ChevronLeft size={18} className="group-hover:-translate-x-1 transition-transform"/>
            <span className="font-medium text-sm">{t.back}</span>
        </button>

        <div className="relative z-10 w-full max-w-[1600px] mx-auto grid lg:grid-cols-2 min-h-screen">
            
            {/* Left: Brand Section */}
            <div className="hidden lg:flex flex-col justify-center p-20 text-white relative">
                <div className="mb-8 animate-fade-in-up">
                    <div className="flex items-center gap-1 mb-6">
                        <span className="text-6xl font-[900] tracking-tighter">ASOCIM</span>
                        <div className="bg-white text-[#002060] px-3 py-1 rounded-md mt-2">
                             <span className="text-2xl font-[900] tracking-widest uppercase">PLUS</span>
                        </div>
                    </div>
                    <h1 className="text-4xl font-bold leading-tight text-blue-100 max-w-xl">
                        The next evolution in <span className="text-white">immersive language learning</span>.
                    </h1>
                </div>
                <div className="space-y-6 max-w-lg animate-fade-in-up delay-200">
                    <div className="flex items-center gap-4 p-4 bg-white/10 rounded-2xl backdrop-blur border border-white/10">
                        <div className="w-12 h-12 rounded-full bg-blue-500/20 flex items-center justify-center text-blue-300">
                            <User size={24} />
                        </div>
                        <div>
                            <h3 className="font-bold">{t.portal}</h3>
                            <p className="text-sm text-blue-200">{t.portalDesc}</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* Right: Login Form */}
            <div className="flex flex-col justify-center p-6 lg:p-24">
                <div className="bg-white/95 backdrop-blur-xl p-10 lg:p-12 rounded-3xl shadow-2xl border border-white/50 max-w-md mx-auto w-full animate-scale-in">
                    <div className="text-center mb-10">
                        <h2 className="text-3xl font-bold text-[#002060] mb-2">{t.welcome}</h2>
                        <p className="text-slate-500">{t.subtitle}</p>
                    </div>

                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1">{t.username}</label>
                            <div className="relative group">
                                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400 group-focus-within:text-[#002060]">
                                    <User size={20} />
                                </div>
                                <input
                                    type="text"
                                    value={username}
                                    onChange={(e) => setUsername(e.target.value)}
                                    className="block w-full pl-12 pr-4 py-4 bg-white border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:border-[#002060] focus:ring-4 focus:ring-[#002060]/10 transition-all outline-none font-medium"
                                    placeholder="Virtualizadora AC"
                                />
                            </div>
                        </div>

                        <div>
                            <label className="block text-xs font-bold text-slate-500 uppercase mb-2 ml-1">{t.password}</label>
                            <div className="relative group">
                                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-slate-400 group-focus-within:text-[#002060]">
                                    <Lock size={20} />
                                </div>
                                <input
                                    type={showPassword ? 'text' : 'password'}
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    className="block w-full pl-12 pr-12 py-4 bg-white border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:border-[#002060] focus:ring-4 focus:ring-[#002060]/10 transition-all outline-none font-medium"
                                    placeholder="••••••••"
                                />
                                <button
                                    type="button"
                                    onClick={() => setShowPassword(!showPassword)}
                                    className="absolute inset-y-0 right-0 pr-4 flex items-center text-slate-400 hover:text-[#002060] transition-colors"
                                >
                                    {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                                </button>
                            </div>
                        </div>

                        <div className="flex items-center justify-between text-sm">
                            <label className="flex items-center gap-2 cursor-pointer">
                                <input type="checkbox" className="w-4 h-4 rounded border-slate-300 text-[#002060] focus:ring-[#002060]" />
                                <span className="text-slate-600 font-medium">{t.remember}</span>
                            </label>
                            <a href="#" className="text-[#002060] font-bold hover:underline">{t.forgot}</a>
                        </div>

                        <button
                            type="submit"
                            disabled={isLoading}
                            className="w-full py-4 bg-[#002060] hover:bg-[#001540] text-white rounded-xl font-bold text-lg shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
                        >
                            {isLoading ? (
                                <span className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                            ) : (
                                <>{t.signIn} <ArrowRight size={20} /></>
                            )}
                        </button>
                    </form>

                    <div className="mt-8 text-center">
                        <p className="text-slate-500 text-sm">
                            {t.noAccount} <a href="#" className="text-[#002060] font-bold hover:underline">{t.apply}</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
};
