
import React, { useState, useEffect } from 'react';
import { ChevronRight, FileText, CheckCircle, Lock, Video, Award, MessageCircle, Clock, GripVertical, RefreshCw, Upload, ExternalLink, Download, XCircle, CheckSquare, Check } from 'lucide-react';
import { Card } from '../components/ui/Card';
import { MOCK_MODULES, MOCK_COURSES, MOCK_PARTICIPANTS, MOCK_GRADES, TRANSLATIONS } from '../constants';
import { ToastType } from '../components/ui/Toast';
import { Language, Activity } from '../types';

interface CourseViewProps {
  courseId: string | null;
  onBack: () => void;
  onShowToast: (message: string, type: ToastType) => void;
  language: Language;
}

const QuizActivity = ({ activity, onComplete, language }: { activity: Activity, onComplete: () => void, language: Language }) => {
    const [answers, setAnswers] = useState<{ [key: string]: number }>({});
    const [showResults, setShowResults] = useState(false);
    const [score, setScore] = useState(0);
    const t = TRANSLATIONS[language].activities.quiz;

    const handleSubmit = () => {
        if (!activity.questions) return;
        let correct = 0;
        activity.questions.forEach(q => {
            if (answers[q.id] === q.correct) correct++;
        });
        setScore(correct);
        setShowResults(true);
        if (correct === activity.questions.length) {
            onComplete();
        }
    };

    return (
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm animate-fade-in-up">
             <h3 className="font-bold text-2xl text-[#002060] mb-4 flex items-center gap-2">
                <Award className="text-amber-500" /> {activity.title}
             </h3>
             
             {!showResults ? (
                 <div className="space-y-8">
                     {activity.questions?.map((q, idx) => (
                         <div key={q.id} className="p-6 bg-slate-50 rounded-xl border border-slate-100">
                             <p className="font-bold text-slate-800 mb-4">{idx + 1}. {q.text}</p>
                             <div className="space-y-3">
                                 {q.options.map((opt, i) => (
                                     <label key={i} className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all ${answers[q.id] === i ? 'bg-blue-50 border-blue-500' : 'bg-white border-slate-200 hover:border-blue-300'}`}>
                                         <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${answers[q.id] === i ? 'border-blue-500 bg-blue-500' : 'border-slate-300'}`}>
                                             {answers[q.id] === i && <div className="w-2 h-2 bg-white rounded-full"></div>}
                                         </div>
                                         <input 
                                            type="radio" 
                                            name={q.id} 
                                            className="hidden" 
                                            onChange={() => setAnswers({...answers, [q.id]: i})}
                                         />
                                         <span className="text-sm text-slate-700 font-medium">{opt}</span>
                                     </label>
                                 ))}
                             </div>
                         </div>
                     ))}
                     <button 
                        onClick={handleSubmit}
                        disabled={Object.keys(answers).length !== activity.questions?.length}
                        className="bg-[#002060] text-white px-8 py-3 rounded-xl font-bold shadow-lg hover:bg-[#00308F] disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                     >
                         {t.submit}
                     </button>
                 </div>
             ) : (
                 <div className="text-center py-8">
                     <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6">
                         <div className="text-4xl font-bold text-[#002060]">{Math.round((score / (activity.questions?.length || 1)) * 100)}%</div>
                     </div>
                     <h4 className="text-xl font-bold text-slate-800 mb-2">{t.completed}</h4>
                     <p className="text-slate-500 mb-8">{t.scored} {score} / {activity.questions?.length}</p>
                     <div className="flex justify-center gap-4">
                         <button onClick={() => {setShowResults(false); setAnswers({});}} className="px-6 py-2 border border-slate-300 rounded-lg font-bold text-slate-600 hover:bg-slate-50">
                             {t.retake}
                         </button>
                         <button onClick={onComplete} className="px-6 py-2 bg-emerald-500 text-white rounded-lg font-bold hover:bg-emerald-600 shadow-md">
                             {t.continue}
                         </button>
                     </div>
                 </div>
             )}
        </div>
    );
};

const AssignmentActivity = ({ activity, onComplete, language }: { activity: Activity, onComplete: () => void, language: Language }) => {
    const [file, setFile] = useState<File | null>(null);
    const [isUploading, setIsUploading] = useState(false);
    const [isSubmitted, setIsSubmitted] = useState(false);
    const t = TRANSLATIONS[language].activities.assignment;

    const handleUpload = () => {
        if(!file) return;
        setIsUploading(true);
        setTimeout(() => {
            setIsUploading(false);
            setIsSubmitted(true);
            onComplete();
        }, 2000);
    };

    return (
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm animate-fade-in-up">
             <h3 className="font-bold text-2xl text-[#002060] mb-2 flex items-center gap-2">
                <FileText className="text-blue-500" /> {activity.title}
             </h3>
             <p className="text-slate-500 mb-8">{activity.content}</p>

             {!isSubmitted ? (
                 <div className="border-2 border-dashed border-slate-300 rounded-xl p-12 text-center bg-slate-50 hover:bg-blue-50 hover:border-blue-300 transition-colors">
                     <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm">
                         <Upload size={32} className="text-blue-500" />
                     </div>
                     {file ? (
                         <div className="mb-6">
                             <p className="font-bold text-slate-800 text-lg">{file.name}</p>
                             <p className="text-sm text-slate-500">{(file.size / 1024).toFixed(2)} KB</p>
                             <button onClick={() => setFile(null)} className="text-red-500 text-sm font-bold mt-2 hover:underline">{t.remove}</button>
                         </div>
                     ) : (
                         <div className="mb-6">
                             <p className="font-bold text-slate-700 text-lg mb-1">{t.drag}</p>
                             <p className="text-sm text-slate-400">{t.browse}</p>
                         </div>
                     )}
                     
                     <input 
                        type="file" 
                        className="hidden" 
                        id="file-upload"
                        onChange={(e) => {
                            if (e.target.files && e.target.files[0]) {
                                setFile(e.target.files[0]);
                            }
                        }}
                     />
                     
                     {!file && (
                        <label htmlFor="file-upload" className="px-6 py-3 bg-white border border-slate-300 rounded-lg font-bold text-slate-600 hover:bg-slate-100 cursor-pointer transition-colors inline-block">
                            {t.select}
                        </label>
                     )}

                     {file && (
                         <button 
                            onClick={handleUpload}
                            className="px-8 py-3 bg-[#002060] text-white rounded-lg font-bold hover:bg-[#00308F] shadow-lg transition-all flex items-center gap-2 mx-auto"
                         >
                             {isUploading ? t.uploading : t.submit} {isUploading && <RefreshCw className="animate-spin" size={16}/>}
                         </button>
                     )}
                 </div>
             ) : (
                 <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-8 text-center">
                     <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm text-emerald-500">
                         <CheckCircle size={32} />
                     </div>
                     <h4 className="text-xl font-bold text-emerald-800 mb-2">{t.success}</h4>
                     <p className="text-emerald-600 mb-6">{t.sent}</p>
                 </div>
             )}
        </div>
    );
};

const ResourceActivity = ({ activity, onComplete, language }: { activity: Activity, onComplete: () => void, language: Language }) => {
    const t = TRANSLATIONS[language].activities.resource;
    return (
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm animate-fade-in-up">
            <div className="flex items-start gap-6">
                <div className={`p-4 rounded-2xl ${activity.type === 'pdf' ? 'bg-red-50 text-red-600' : 'bg-blue-50 text-blue-600'}`}>
                    {activity.type === 'pdf' ? <FileText size={40} /> : <Video size={40} />}
                </div>
                <div className="flex-1">
                    <h3 className="font-bold text-2xl text-slate-800 mb-2">{activity.title}</h3>
                    <p className="text-slate-500 mb-6 leading-relaxed">{activity.content}</p>
                    
                    <div className="flex flex-wrap gap-4">
                        <button 
                            onClick={() => {
                                window.open(activity.linkUrl || activity.fileUrl, '_blank');
                                onComplete();
                            }}
                            className="px-6 py-3 bg-[#002060] text-white rounded-xl font-bold shadow-md hover:bg-[#00308F] flex items-center gap-2 transition-colors"
                        >
                            {activity.type === 'pdf' ? <Download size={18} /> : <ExternalLink size={18} />}
                            {activity.type === 'pdf' ? t.download : t.open}
                        </button>
                        
                        {!activity.isCompleted && (
                            <button 
                                onClick={onComplete}
                                className="px-6 py-3 border border-slate-200 text-slate-600 rounded-xl font-bold hover:bg-slate-50 flex items-center gap-2 transition-colors"
                            >
                                <CheckSquare size={18} /> {t.markDone}
                            </button>
                        )}

                        {activity.isCompleted && (
                            <span className="px-4 py-3 bg-emerald-50 text-emerald-700 rounded-xl font-bold flex items-center gap-2 border border-emerald-100">
                                <Check size={18} /> {t.completed}
                            </span>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

const H5PDragAndDrop = ({ onComplete, language }: { onComplete?: () => void, language: Language }) => {
    const [matches, setMatches] = useState<{ [key: string]: string | null }>({ 'zone1': null, 'zone2': null, 'zone3': null });
    const [selectedItem, setSelectedItem] = useState<string | null>(null);
    const [isChecked, setIsChecked] = useState(false);
    const [score, setScore] = useState(0);
    const t = TRANSLATIONS[language].activities.h5p;

    const items = ['Apple', 'Car', 'Book'];
    const zones = [
        { id: 'zone1', label: 'A red fruit', match: 'Apple' },
        { id: 'zone2', label: 'A vehicle with wheels', match: 'Car' },
        { id: 'zone3', label: 'Something to read', match: 'Book' }
    ];

    const handleItemClick = (item: string) => {
        if (isChecked) return;
        if (Object.values(matches).includes(item)) {
             const newMatches = {...matches};
             const key = Object.keys(newMatches).find(k => newMatches[k] === item);
             if(key) newMatches[key] = null;
             setMatches(newMatches);
             return;
        }
        setSelectedItem(item);
    };

    const handleZoneClick = (zoneId: string) => {
        if (isChecked || !selectedItem) return;
        setMatches(prev => ({ ...prev, [zoneId]: selectedItem }));
        setSelectedItem(null);
    };

    const checkAnswers = () => {
        let correct = 0;
        zones.forEach(z => {
            if (matches[z.id] === z.match) correct++;
        });
        setScore(correct);
        setIsChecked(true);
        if (correct === 3 && onComplete) onComplete();
    };

    const reset = () => {
        setMatches({ 'zone1': null, 'zone2': null, 'zone3': null });
        setIsChecked(false);
        setScore(0);
        setSelectedItem(null);
    };

    return (
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm animate-fade-in-up">
             <div className="flex items-center justify-between mb-6 border-b border-slate-100 pb-4">
                 <h3 className="font-bold text-[#002060] flex items-center gap-2">
                     <span className="bg-[#002060] text-white text-xs px-2 py-0.5 rounded">H5P</span>
                     {t.dragTitle}
                 </h3>
                 <div className="text-sm text-slate-500">{t.task}</div>
             </div>

             <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 mb-6 flex gap-4 justify-center min-h-[80px] items-center">
                 {items.map(item => {
                     const isPlaced = Object.values(matches).includes(item);
                     if (isPlaced) return null;
                     return (
                         <button
                             key={item}
                             onClick={() => handleItemClick(item)}
                             className={`px-6 py-2 rounded-lg font-bold shadow-sm border-b-4 transition-all active:scale-95 ${selectedItem === item ? 'bg-blue-600 text-white border-blue-800 scale-110' : 'bg-white text-slate-700 border-slate-200 hover:border-blue-300'}`}
                         >
                             <div className="flex items-center gap-2">
                                 <GripVertical size={14} className="opacity-50"/> {item}
                             </div>
                         </button>
                     )
                 })}
             </div>

             <div className="grid md:grid-cols-3 gap-4 mb-8">
                 {zones.map(zone => (
                     <div 
                        key={zone.id} 
                        onClick={() => handleZoneClick(zone.id)}
                        className={`p-6 rounded-xl border-2 border-dashed transition-all cursor-pointer relative min-h-[120px] flex flex-col items-center justify-center ${selectedItem ? 'border-blue-300 bg-blue-50 hover:bg-blue-100' : 'border-slate-200 bg-white'}`}
                     >
                         <span className="text-slate-500 text-sm mb-2 font-medium">{zone.label}</span>
                         {matches[zone.id] && (
                             <div className={`px-4 py-2 rounded-lg font-bold shadow-sm text-white animate-scale-in ${isChecked ? (matches[zone.id] === zone.match ? 'bg-green-500' : 'bg-red-500') : 'bg-[#002060]'}`}>
                                 {matches[zone.id]}
                             </div>
                         )}
                     </div>
                 ))}
             </div>

             <div className="flex items-center justify-between">
                 <div className="flex items-center gap-2">
                     {isChecked && (
                         <span className="font-bold text-lg text-[#002060]">{t.score}: {score} / 3</span>
                     )}
                 </div>
                 <div className="flex gap-3">
                     {isChecked ? (
                         <button onClick={reset} className="flex items-center gap-2 px-6 py-2 rounded-lg bg-slate-100 text-slate-700 font-bold hover:bg-slate-200 transition-colors">
                             <RefreshCw size={18}/> {t.retry}
                         </button>
                     ) : (
                         <button onClick={checkAnswers} className="flex items-center gap-2 px-6 py-2 rounded-lg bg-[#002060] text-white font-bold hover:bg-[#00308F] transition-colors shadow-lg shadow-blue-900/20">
                             <CheckCircle size={18}/> {t.check}
                         </button>
                     )}
                 </div>
             </div>
        </div>
    );
};

export const CourseView: React.FC<CourseViewProps> = ({ courseId, onBack, onShowToast, language }) => {
  const [activeTab, setActiveTab] = useState('Course');
  const [activeActivityId, setActiveActivityId] = useState<string | null>(null);
  const t = TRANSLATIONS[language].course;
  
  const course = MOCK_COURSES.find(c => c.id === courseId) || MOCK_COURSES[0];

  const handleActivityClick = (activity: Activity) => {
      if (activity.isLocked) {
          onShowToast(t.locked, 'error');
      } else {
          setActiveActivityId(activity.id);
          window.scrollTo({ top: 0, behavior: 'smooth' });
          if (activity.type !== 'h5p-drag') {
             onShowToast(`Opening ${activity.title}`, 'info');
          }
      }
  };

  const tabNames: { [key: string]: string } = {
      'Course': t.course,
      'Participants': t.participants,
      'Grades': t.grades,
      'Competencies': t.competencies
  };

  const renderActivityView = () => {
      const activity = MOCK_MODULES.flatMap(m => m.activities).find(a => a.id === activeActivityId);
      if (!activity) return null;

      const commonProps = { activity, onComplete: () => onShowToast('Activity Completed', 'success'), language };

      switch (activity.type) {
          case 'quiz': return <QuizActivity {...commonProps} />;
          case 'assignment': return <AssignmentActivity {...commonProps} />;
          case 'h5p-drag': return <H5PDragAndDrop onComplete={() => onShowToast('Activity Completed', 'success')} language={language} />;
          default: return <ResourceActivity {...commonProps} />;
      }
  };

  const renderTabContent = () => {
      switch (activeTab) {
          case 'Participants':
              return (
                  <div className="animate-fade-in-up">
                      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
                          <table className="w-full text-left text-sm">
                              <thead className="bg-slate-50 border-b border-slate-100">
                                  <tr>
                                      <th className="px-6 py-4 font-bold text-slate-700">User</th>
                                      <th className="px-6 py-4 font-bold text-slate-700">Role</th>
                                      <th className="px-6 py-4 font-bold text-slate-700">Last Access</th>
                                      <th className="px-6 py-4 font-bold text-slate-700">Actions</th>
                                  </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-100">
                                  {MOCK_PARTICIPANTS.map((p) => (
                                      <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                                          <td className="px-6 py-4">
                                              <div className="flex items-center gap-3">
                                                  <img src={p.avatar} className="w-8 h-8 rounded-full object-cover" alt={p.name} />
                                                  <div>
                                                      <p className="font-bold text-slate-800">{p.name}</p>
                                                      <p className="text-xs text-slate-400">{p.email}</p>
                                                  </div>
                                              </div>
                                          </td>
                                          <td className="px-6 py-4">
                                              <span className={`px-2 py-1 rounded text-xs font-bold uppercase ${p.role === 'Teacher' ? 'bg-purple-50 text-purple-600' : 'bg-slate-100 text-slate-600'}`}>
                                                  {p.role}
                                              </span>
                                          </td>
                                          <td className="px-6 py-4 text-slate-600">{p.lastAccess}</td>
                                          <td className="px-6 py-4">
                                              <button onClick={() => onShowToast(`Messaged ${p.name}`, 'info')} className="p-2 hover:bg-blue-50 text-slate-400 hover:text-blue-600 rounded-full transition-colors">
                                                  <MessageCircle size={16} />
                                              </button>
                                          </td>
                                      </tr>
                                  ))}
                              </tbody>
                          </table>
                      </div>
                  </div>
              );
          case 'Grades':
              return (
                  <div className="animate-fade-in-up">
                       <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
                            <table className="w-full text-left text-sm">
                                <thead className="bg-slate-50 border-b border-slate-100">
                                    <tr>
                                        <th className="px-6 py-4 font-bold text-slate-700">Item</th>
                                        <th className="px-6 py-4 font-bold text-slate-700">Range</th>
                                        <th className="px-6 py-4 font-bold text-slate-700">Percentage</th>
                                        <th className="px-6 py-4 font-bold text-slate-700">Grade</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100">
                                    {MOCK_GRADES.filter(g => g.courseName.includes(course.title.split(' ')[0]) || true).map((grade) => (
                                        <tr key={grade.id} className="hover:bg-slate-50 transition-colors">
                                            <td className="px-6 py-4 font-bold text-slate-800">{grade.item}</td>
                                            <td className="px-6 py-4 text-slate-600">{grade.range}</td>
                                            <td className="px-6 py-4">
                                                <div className="flex items-center gap-2">
                                                    <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                                                        <div className="h-full bg-emerald-500" style={{ width: grade.percentage }}></div>
                                                    </div>
                                                    <span className="text-slate-600">{grade.percentage}</span>
                                                </div>
                                            </td>
                                            <td className="px-6 py-4 font-bold text-[#002060]">{grade.grade}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                       </div>
                  </div>
              );
          case 'Competencies':
              return (
                  <div className="animate-fade-in-up grid grid-cols-1 md:grid-cols-2 gap-6">
                      {[1,2,3].map(i => (
                          <Card key={i} className="p-6 border-l-4 border-l-amber-500">
                               <div className="flex items-start gap-4">
                                   <div className="p-3 bg-amber-50 text-amber-600 rounded-full">
                                       <Award size={24} />
                                   </div>
                                   <div>
                                       <h3 className="font-bold text-slate-800 text-lg">Clinical Research Mastery Level {i}</h3>
                                       <p className="text-slate-500 text-sm mt-1 mb-4">Demonstrate understanding of core principles in clinical settings.</p>
                                       <span className="bg-emerald-50 text-emerald-700 px-3 py-1 rounded-full text-xs font-bold border border-emerald-100">
                                           Proficient
                                       </span>
                                   </div>
                               </div>
                          </Card>
                      ))}
                  </div>
              );
          default: // Course Modules
              return (
                <div className="space-y-8">
                    {activeActivityId && (
                        <div className="mb-8 relative">
                             <button onClick={() => setActiveActivityId(null)} className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 z-10 p-2 bg-white/50 rounded-full"><XCircle size={24}/></button>
                             {renderActivityView()}
                        </div>
                    )}

                    {MOCK_MODULES.map((module, index) => (
                        <div key={module.id} className={`animate-fade-in-up delay-${(index + 1) * 100}`}>
                            <div className="flex items-center gap-4 mb-4">
                                <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#0056b3] to-[#002060] text-white flex items-center justify-center font-bold text-xl shadow-lg shadow-blue-900/20">
                                    {index + 1}
                                </div>
                                <h2 className="text-xl font-bold text-slate-800">{module.title}</h2>
                            </div>

                            <div className="space-y-3 pl-4 lg:pl-8 border-l-2 border-slate-200 ml-6">
                                {module.activities.map((activity) => (
                                    <Card 
                                        key={activity.id} 
                                        onClick={() => handleActivityClick(activity)}
                                        className={`group hover:shadow-md transition-all cursor-pointer border-l-4 ${activity.isCompleted ? 'border-l-emerald-500' : 'border-l-transparent hover:border-l-[#002060]'} ${activity.isLocked ? 'opacity-75 grayscale-[0.5]' : ''} ${activeActivityId === activity.id ? 'ring-2 ring-blue-100 bg-blue-50/30' : ''}`}
                                    >
                                        <div className="flex items-center justify-between p-4">
                                            <div className="flex items-center gap-4">
                                                <div className={`p-3 rounded-xl ${activity.type === 'pdf' ? 'bg-red-50 text-red-600' : activity.type === 'link' ? 'bg-blue-50 text-blue-600' : activity.type === 'h5p-drag' ? 'bg-[#002060] text-white' : 'bg-amber-50 text-amber-600'}`}>
                                                    {activity.type === 'pdf' && <FileText size={20} />}
                                                    {activity.type === 'link' && <Video size={20} />}
                                                    {activity.type === 'quiz' && <Award size={20} />}
                                                    {activity.type === 'assignment' && <FileText size={20} />}
                                                    {activity.type === 'h5p-drag' && <GripVertical size={20} />}
                                                </div>
                                                <div>
                                                    <span className="font-bold text-slate-800 group-hover:text-[#002060] transition-colors block">{activity.title}</span>
                                                    <span className="text-xs text-slate-400 uppercase tracking-wider font-medium">{activity.type}</span>
                                                </div>
                                            </div>
                                            
                                            <div className="flex items-center gap-3">
                                                {activity.isCompleted ? (
                                                    <CheckCircle size={22} className="text-emerald-500 fill-emerald-50" />
                                                ) : activity.isLocked ? (
                                                    <Lock size={20} className="text-slate-300" />
                                                ) : (
                                                    <div className="w-5 h-5 rounded-full border-2 border-slate-200 group-hover:border-[#002060] transition-colors"></div>
                                                )}
                                            </div>
                                        </div>
                                    </Card>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
              );
      }
  };

  return (
    <div className="bg-slate-50 min-h-screen pb-20">
      {/* Course Hero Header */}
      <div className="relative h-[280px] w-full overflow-hidden">
        <img src={course.thumbnail} className="absolute inset-0 w-full h-full object-cover blur-[2px] scale-105" alt="Header" />
        <div className="absolute inset-0 bg-[#002060]/90 mix-blend-multiply"></div>
        
        <div className="absolute inset-0 flex flex-col justify-center max-w-7xl mx-auto px-4 lg:px-8 animate-fade-in-up">
            <button onClick={onBack} className="text-blue-200 hover:text-white text-sm font-medium flex items-center gap-1 w-fit mb-6 transition-colors">
                <ChevronRight size={16} className="rotate-180" /> {t.backToDash}
            </button>
            <div className="flex items-center gap-3 mb-3">
                <span className="px-2 py-1 rounded bg-white/10 backdrop-blur text-xs font-bold text-white border border-white/20 uppercase tracking-wider">
                    {course.category}
                </span>
                <span className="text-blue-200 text-sm flex items-center gap-1">
                    <Clock size={14} /> 4 {t.weeksLeft}
                </span>
            </div>
            <h1 className="text-3xl lg:text-4xl font-bold text-white mb-2 shadow-sm">{course.title}</h1>
            <div className="flex items-center gap-2 text-blue-100 text-sm">
                <div className="flex -space-x-2">
                     {MOCK_PARTICIPANTS.slice(0,3).map((p) => (
                         <img key={p.id} src={p.avatar} className="w-6 h-6 rounded-full border border-[#002060] object-cover" alt="User" />
                     ))}
                </div>
                <span>+124 {t.participants}</span>
            </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="sticky top-20 z-30 px-4 lg:px-8 -mt-8">
          <div className="max-w-7xl mx-auto bg-white rounded-xl shadow-lg shadow-slate-200/50 p-1.5 flex gap-1 border border-slate-100 overflow-x-auto">
              {['Course', 'Participants', 'Grades', 'Competencies'].map((tab) => (
                  <button
                      key={tab}
                      onClick={() => setActiveTab(tab)}
                      className={`px-6 py-2.5 rounded-lg text-sm font-bold transition-all whitespace-nowrap flex-1 md:flex-none text-center ${
                          activeTab === tab 
                          ? 'bg-[#002060] text-white shadow-md transform scale-105' 
                          : 'text-slate-500 hover:text-slate-800 hover:bg-slate-50'
                      }`}
                  >
                      {tabNames[tab]}
                  </button>
              ))}
          </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 lg:px-8 mt-8 flex flex-col lg:flex-row gap-8">
         <div className="flex-grow">
            {renderTabContent()}
         </div>
         {/* Sidebar */}
         <div className="lg:w-80 space-y-6 animate-fade-in-right delay-300 hidden lg:block">
             <Card className="bg-white border-slate-100 shadow-sm p-6">
                 <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
                    <Award className="text-amber-500" size={18} /> {t.progress}
                 </h3>
                 <div className="relative w-32 h-32 mx-auto mb-4">
                      <svg className="w-full h-full transform -rotate-90">
                        <circle cx="64" cy="64" r="56" className="text-slate-100 stroke-current" strokeWidth="12" fill="none" />
                        <circle cx="64" cy="64" r="56" className="text-[#0056b3] stroke-current" strokeWidth="12" fill="none" strokeDasharray="351" strokeDashoffset={351 - (351 * course.progress) / 100} strokeLinecap="round" />
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center flex-col">
                          <span className="text-2xl font-bold text-[#002060]">{course.progress}%</span>
                      </div>
                 </div>
             </Card>
             <div className="bg-gradient-to-br from-[#002060] to-[#003377] rounded-2xl p-6 text-white shadow-lg">
                <h3 className="font-bold mb-4">{t.instructor}</h3>
                <div className="flex items-center gap-4 mb-4">
                    <img src="https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=100&auto=format&fit=crop" className="w-12 h-12 rounded-full border-2 border-white/20" alt="Instructor" />
                    <div>
                        <p className="font-bold">Dr. R. Smith</p>
                        <p className="text-xs text-blue-200">Head of Research</p>
                    </div>
                </div>
                <button onClick={() => onShowToast('Opening chat...', 'info')} className="w-full py-2 bg-white/10 hover:bg-white/20 rounded-lg text-sm font-medium transition-colors flex items-center justify-center gap-2">
                    <MessageCircle size={16} /> {t.sendMessage}
                </button>
             </div>
         </div>
      </div>
    </div>
  );
};
