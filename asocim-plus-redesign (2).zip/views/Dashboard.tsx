
import React from 'react';
import { ArrowRight, CheckCircle, FileText, Calendar, Users, Globe, Play, Clock } from 'lucide-react';
import { ProgressBar } from '../components/ui/ProgressBar';
import { MOCK_COURSES, TRANSLATIONS } from '../constants';
import { ToastType } from '../components/ui/Toast';
import { Card } from '../components/ui/Card';
import { Page, Language } from '../types';

interface DashboardProps {
  onCourseSelect: (id: string) => void;
  onShowToast: (message: string, type: ToastType) => void;
  onNavigate: (page: Page) => void;
  language: Language;
  userName: string;
}

export const Dashboard: React.FC<DashboardProps> = ({ onCourseSelect, onShowToast, onNavigate, language, userName }) => {
  const activeCourse = MOCK_COURSES[0];
  const t = TRANSLATIONS[language].dashboard;

  const quickAccessTools = [
    { label: t.tools.grades, icon: CheckCircle, color: 'text-emerald-600', bg: 'bg-emerald-50', desc: t.tools.gradesDesc, page: Page.GRADES },
    { label: t.tools.notes, icon: FileText, color: 'text-blue-600', bg: 'bg-blue-50', desc: t.tools.notesDesc, page: Page.COURSE }, 
    { label: t.tools.calendar, icon: Calendar, color: 'text-rose-600', bg: 'bg-rose-50', desc: t.tools.calendarDesc, page: Page.CALENDAR },
    { label: t.tools.community, icon: Users, color: 'text-violet-600', bg: 'bg-violet-50', desc: t.tools.communityDesc, page: Page.COMMUNITY },
    { label: t.tools.siteHome, icon: Globe, color: 'text-amber-600', bg: 'bg-amber-50', desc: t.tools.siteHomeDesc, page: Page.DASHBOARD },
  ];

  return (
    <div className="min-h-[calc(100vh-5rem)] pb-20">
      {/* Hero Banner */}
      <div className="relative h-[300px] lg:h-[380px] w-full overflow-hidden group">
        <img 
            src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?q=80&w=2070&auto=format&fit=crop" 
            className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
            alt="Dashboard Hero"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#002060]/95 via-[#002060]/80 to-transparent"></div>
        
        <div className="absolute inset-0 max-w-7xl mx-auto px-6 lg:px-12 flex flex-col justify-center animate-fade-in-up">
             <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/20 text-white/90 text-xs font-bold tracking-wider w-fit mb-4 backdrop-blur-md">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                {t.academic}
             </span>
             <h1 className="text-4xl lg:text-5xl font-bold text-white mb-4 leading-tight">
                {t.welcome}<br/>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-200 to-teal-200">{userName}</span>
             </h1>
             <p className="text-blue-100 max-w-lg text-lg mb-8 font-light">
                {t.assignments.replace('{count}', '3')}
             </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-12 -mt-20 relative z-10 space-y-12">
        
        {/* Active Course Card */}
        <div className="bg-white rounded-3xl shadow-xl shadow-blue-900/5 border border-slate-100 p-1 overflow-hidden animate-fade-in-up delay-100">
            <div className="flex flex-col lg:flex-row">
                <div className="lg:w-2/5 relative min-h-[240px] lg:min-h-full overflow-hidden rounded-t-2xl lg:rounded-l-2xl lg:rounded-tr-none">
                    <img src={activeCourse.thumbnail} className="absolute inset-0 w-full h-full object-cover hover:scale-110 transition-transform duration-700" alt="Course" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent lg:bg-gradient-to-r"></div>
                    <div className="absolute bottom-6 left-6 text-white">
                         <span className="bg-blue-600/90 backdrop-blur-sm px-3 py-1 rounded-lg text-xs font-bold uppercase tracking-wide mb-2 inline-block shadow-lg">
                            {t.inProgress}
                         </span>
                    </div>
                </div>
                <div className="lg:w-3/5 p-8 lg:p-10 flex flex-col justify-center">
                    <div className="flex justify-between items-start mb-4">
                        <h2 className="text-2xl lg:text-3xl font-bold text-slate-900">{activeCourse.title}</h2>
                        <div className="hidden lg:block">
                            <div className="w-12 h-12 rounded-full bg-blue-50 flex items-center justify-center text-[#002060]">
                                <Play size={24} fill="currentColor" className="ml-1" />
                            </div>
                        </div>
                    </div>
                    
                    <div className="flex items-center gap-4 text-slate-500 mb-8">
                        <div className="flex items-center gap-2 text-sm font-medium bg-slate-50 px-3 py-1.5 rounded-lg">
                            <Clock size={16} className="text-blue-500" />
                            <span>{t.next}</span>
                        </div>
                        <span className="text-slate-300">|</span>
                        <span className="text-sm">Module 1</span>
                    </div>

                    <div className="space-y-3 mb-8">
                        <div className="flex justify-between text-sm font-bold">
                            <span className="text-slate-700">{t.progress}</span>
                            <span className="text-[#0056b3]">{activeCourse.progress}%</span>
                        </div>
                        <ProgressBar progress={activeCourse.progress} className="h-3 bg-slate-100" colorClass="bg-gradient-to-r from-[#0056b3] to-teal-400" />
                    </div>

                    <button 
                        onClick={() => onCourseSelect(activeCourse.id)}
                        className="w-full lg:w-fit bg-[#002060] hover:bg-[#00308F] text-white font-bold py-3.5 px-8 rounded-xl shadow-lg shadow-blue-900/20 transition-all transform hover:-translate-y-1 flex items-center justify-center gap-2"
                    >
                        {t.continue} <ArrowRight size={18} />
                    </button>
                </div>
            </div>
        </div>

        {/* Quick Access Grid */}
        <section className="animate-fade-in-up delay-200">
            <h3 className="text-xl font-bold text-slate-800 mb-6">{t.quickAccess}</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                {quickAccessTools.map((tool, idx) => (
                    <button 
                        key={idx}
                        onClick={() => {
                            if (tool.page === Page.COURSE) {
                                onCourseSelect(activeCourse.id);
                            } else if (tool.page) {
                                onNavigate(tool.page);
                            } else {
                                onShowToast(`Opening ${tool.label}`, 'info');
                            }
                        }}
                        className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-xl hover:shadow-blue-900/5 transition-all duration-300 hover:-translate-y-1 group text-left"
                    >
                        <div className={`w-12 h-12 rounded-xl ${tool.bg} ${tool.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                            <tool.icon size={24} />
                        </div>
                        <div className="font-bold text-slate-800 group-hover:text-[#002060] transition-colors">{tool.label}</div>
                        <div className="text-xs text-slate-400 mt-1">{tool.desc}</div>
                    </button>
                ))}
            </div>
        </section>

        {/* Other Courses Grid */}
        <section className="animate-fade-in-up delay-300">
            <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-800">{t.moreCourses}</h3>
                <button className="text-sm font-bold text-blue-600 hover:underline">{t.viewAll}</button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {MOCK_COURSES.slice(1).map((course) => (
                    <Card 
                        key={course.id}
                        onClick={() => onCourseSelect(course.id)}
                        className="group hover:-translate-y-1 hover:shadow-lg transition-all p-0 overflow-hidden border-0"
                    >
                        <div className="relative h-40 overflow-hidden">
                            <img src={course.thumbnail} alt={course.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors"></div>
                            <div className="absolute top-3 right-3 bg-white/90 backdrop-blur px-2 py-1 rounded text-xs font-bold text-slate-800 uppercase shadow-sm">
                                {course.category}
                            </div>
                        </div>
                        <div className="p-6">
                            <h4 className="font-bold text-lg text-slate-800 mb-2 line-clamp-2 group-hover:text-[#002060] transition-colors">
                                {course.title}
                            </h4>
                            <div className="flex items-center gap-2 mt-4">
                                <ProgressBar progress={course.progress} className="h-1.5 flex-grow bg-slate-100" colorClass={course.progress === 100 ? 'bg-emerald-500' : 'bg-blue-500'} />
                                <span className="text-xs font-bold text-slate-400">{course.progress}%</span>
                            </div>
                        </div>
                    </Card>
                ))}
            </div>
        </section>

      </div>
    </div>
  );
};
